package Access_Modifier4;

//import Access_modifier3.CClass;

public class Dclass {
	public static void main(String arg[]) {
		EClass e =new EClass();
	
		
		System.out.println(e.defaultmessage);
		System.out.println(e.protectedmessge1);
	
	}
}
