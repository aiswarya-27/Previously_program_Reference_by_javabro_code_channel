package Access_Modifier4;

public class EClass extends Dclass{
	//Default (no modifier): Accessible only within the same package.
String defaultmessage = "this my default message in Eclass";
protected String protectedmessge1 ="this my sample protected messge";
}
