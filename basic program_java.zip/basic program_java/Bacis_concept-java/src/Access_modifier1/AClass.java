package Access_modifier1;

import Access_modifier3.CClass;

public class AClass extends CClass{
// super class name: AClass , sub class name :CClass
	public static void main(String args[]) {
		 AClass a = new AClass(); // Access through subclass instance
	        System.out.println(a.publicmessage); // Public field is accessible
	        System.out.println(a.protectedmessage); // Protected field is now accessible because AClass is a subclass
	}
}
