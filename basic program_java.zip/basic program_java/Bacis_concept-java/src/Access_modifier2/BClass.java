package Access_modifier2;

import Access_Modifier4.EClass;

public class BClass extends EClass {
	public static void main(String args[]) {
		BClass b = new BClass() ;
		// Protected field is now accessible because BClass is a subclass
			System.out.println(b.protectedmessge1);
		
	}
}
