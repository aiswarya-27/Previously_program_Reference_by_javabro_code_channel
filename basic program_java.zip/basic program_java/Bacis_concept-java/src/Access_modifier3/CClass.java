package Access_modifier3;

//import Access_Modifier4.Dclass;
//import Access_modifier1.AClass;

public class CClass {
	//Public: Accessible from any other class in any package.
	public String publicmessage="this my public message";
	
	//Protected: Accessible within the same package or by subclasses in different packages.
protected String protectedmessage="this my Protected message in CClass";
	
}
