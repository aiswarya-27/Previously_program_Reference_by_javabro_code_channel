package ExceptionHandling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exceptionhandlingmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner( System.in);
try {
System.out.println("Pls enter interger datatypes there");

	System.out.println("compare two number in the multilple");
	int a= scanner.nextInt();
	
	System.out.println("");
	
System.out.println("enter the number only");
int b= scanner.nextInt();

int c=a*b;
System.out.println("Result:"+c);
}

/*Whenever I try to write any string value in the console, that why i have write the line 27 to 29*/
catch(InputMismatchException e) {
	System.out.println("don't print string data types here ");
}
/*That is a good practice for handling exceptions*/
catch(Exception e) {
	System.out.println("this is wrong msg");
}
/* any scanner open mean i have close like this line 35 to 37*/
finally {
	System.out.println("tested prpertly");
}
}

}
