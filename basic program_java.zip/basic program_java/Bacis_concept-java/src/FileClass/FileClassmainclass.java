package FileClass;

import java.io.File;

public class FileClassmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File file =new File("sample.txt");
File file1=new File("OrderDetails 6.txt");
File file2=new File("Headcount.csv");
//In my C drive, I have a Spring Boot application. Which files do I need to upload? The files are in the same location

if(file.exists()) {
	System.out.println("FileName:"+file.getPath());    // call the file name reference the 9 line

	System.out.println("FilePathName:"+file.getAbsolutePath());  // path 
	System.out.println("FilePrsentOrNot:"+file.isFile()); // the file present or not
	
	System.out.println("");
	System.out.println("FileName1:"+file1.getPath());    // call the file name reference the 10 line

	System.out.println("FilePathName1:"+file1.getAbsolutePath());  // path 
	System.out.println("FilePrsentOrNot1:"+file1.isFile()); // the file present or not
	
	System.out.println("");
	System.out.println("FileName2:"+file2.getPath());    // call the file name reference the 11 line

	System.out.println("FilePathName2:"+file2.getAbsolutePath());  // path 
	System.out.println("FilePrsentOrNot2:"+file2.isFile()); // the file present or not
}
else {
	System.out.println("This is wrong msg");
}
	}

}
