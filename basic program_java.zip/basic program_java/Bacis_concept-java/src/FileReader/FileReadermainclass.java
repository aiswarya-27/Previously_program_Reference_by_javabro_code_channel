package FileReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReadermainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			  FileReader reader = new FileReader("C:/BGV_BackEnd/Bacis_concept-java/sample.txt");
            int data = reader.read();
            while (data != -1) { // Corrected syntax here
                System.out.print((char) data); // Changed to print instead of println for proper file content display
                data = reader.read();
            }
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) { // Added IOException to handle potential issues with reader.read()
            e.printStackTrace();
        }
    }
}