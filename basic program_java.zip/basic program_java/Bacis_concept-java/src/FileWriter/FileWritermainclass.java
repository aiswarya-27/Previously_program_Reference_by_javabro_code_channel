package FileWriter;

import java.io.FileWriter;
import java.io.IOException;

public class FileWritermainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	FileWriter writer =new FileWriter("Pom.text");
	FileWriter writer1=new FileWriter("Test.txt");
	
	writer.write("this my test sampl1 \n this my test sample2 \n this my test sample3\n");
	writer.write("tested completed");
	writer.append("this my sample testing");
	writer.close();
	
	writer1.write("this my dump data \n this sample data \n");
	writer1.append("this my dump data testing");
	writer1.close();
	
	// auto generated the line 14 to 17
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
