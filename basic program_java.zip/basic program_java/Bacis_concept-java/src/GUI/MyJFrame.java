package GUI;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class MyJFrame extends JFrame{


		// TODO Auto-generated method stub
//sub class name, child class name: MyJFrame  , main class name,parents calss name: JFrame
		MyJFrame(){
			
			this.setVisible(true);     //make a frame is visible
			this.setTitle("Sample Window");  // title name u can top left side
			this.setSize(600, 600);    // set the x-dimension and y- dimension
			this.setResizable(false);   //present the frame is not resizable
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //exit out of the application
			 
			ImageIcon image =new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//GUI//image.png");    // i can change the logo means
			//ImageIcon image =new ImageIcon("image.png"); 
			this.setIconImage(image.getImage());   // visible the image
			//a.setBackground(Color.yellow);    // it is not working for your reference
			//a.getContentPane().setBackground(Color.BLACK);  // background color change
			//a.getContentPane().setBackground(new Color(56,0,8));  // background color change
			this.getContentPane().setBackground(new Color(219, 112, 147));  // HTML Color Names (RGB Code)
			this.getContentPane().setBackground(new Color(0xCD5C5C));  // HTML Color Names (Hex Code)  u need write the 0x is required

		}
		
	}

	


