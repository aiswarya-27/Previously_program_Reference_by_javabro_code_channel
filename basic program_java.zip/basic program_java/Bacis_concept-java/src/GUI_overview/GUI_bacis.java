package GUI_overview;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class GUI_bacis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner= new Scanner(System.in);
		String name= JOptionPane.showInputDialog("enter the name");
		JOptionPane.showInputDialog(null,"hello this my name"+name);
		
	int age= Integer.parseInt(JOptionPane.showInputDialog("enter the age"));
		JOptionPane.showInputDialog(null,"this my age"+age);
	}

}
