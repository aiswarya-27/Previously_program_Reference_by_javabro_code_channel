package GUI_overview;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class NewWindow {

	
	JFrame frame = new JFrame();
	JLabel lable= new JLabel("hello");
	
	// constructor
	NewWindow (){
		frame.setBounds(50, 50, 150, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		
		lable.setBounds(50,50, 200, 200);
		lable.setFocusable(false);
        lable.setFont(new Font(null,Font.PLAIN,25));

		
		frame.add(lable);
		frame.setVisible(true);
	
	
	}

}
