package GUI_overview;

public class Open_GUI_Window {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Open_a_new_window  open= new Open_a_new_window();
	}

}
