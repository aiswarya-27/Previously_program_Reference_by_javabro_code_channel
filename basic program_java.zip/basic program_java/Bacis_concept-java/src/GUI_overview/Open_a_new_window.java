package GUI_overview;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Open_a_new_window implements ActionListener {

	
	JFrame frame = new JFrame();
	JButton button = new JButton("This my sample new window button name");
	
	// constructor
	Open_a_new_window(){
		frame.setBounds(50, 50, 150, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		
		button.setBounds(50,50, 200, 200);
		button.setFocusable(false);
		button.addActionListener(this);
		
		frame.add(button);
		frame.setVisible(true);
	
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource()==button) {
		frame.dispose();
		NewWindow newwindow = new NewWindow();
		}
		
	}
}
