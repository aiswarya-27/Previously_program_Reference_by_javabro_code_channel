package Labels;


import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class Labelsmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImageIcon imagesample = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//Labels//truck-160464_640.png");
		Border order=BorderFactory.createLineBorder(Color.ORANGE);
		
JLabel b= new JLabel();// create the label
b.setVisible(true);   //label is visible
b.setIcon(imagesample);  // what are the user give image means that image should be visible
b.setText("kindly write some code there");
b.setBackground(Color.green);  // set the background color
b.setSize(350, 450);    // lable size
b.setHorizontalTextPosition(JLabel.CENTER); // set text centre,top,bottom,left,right imageicon
b.setVerticalTextPosition(JLabel.TOP); //set text centre,top,bottom,left,right imageicon
b.setHorizontalAlignment(JLabel.CENTER); // set Horizontal position of image+text within label
b.setVerticalAlignment(JLabel.CENTER);    //set Vertical position of image+text within label
b.setOpaque(true); // Enable the background color
b.setBorder(order);  //set of label (not image+text )
b.setIconTextGap(-5);  //gap of image to text

		 
		JFrame a= new JFrame(); // create the frame
		a.setVisible(true);    // frame is visible
		a.setTitle("Test Window");    // title name of frame
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		a.setSize(450,450);
		
		
        // Add the label to the frame
        //b.setBounds(50, 50, 350, 350); // Position and size of the label in the frame
        a.add(b); // Add the label to the frame

	}

}
