package OOPs;

public abstract class Abstraction1 {
 void method() {
	}
 void sample() {
	 
 }

}
