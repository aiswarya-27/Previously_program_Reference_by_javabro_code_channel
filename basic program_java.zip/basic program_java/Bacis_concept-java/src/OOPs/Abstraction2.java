package OOPs;

public  class Abstraction2 extends Abstraction1 {
	void method() {
		System.out.println("this my abstraction data Abstraction2 ");
	}
	void sample() {
		System.out.println("this my sample method name");
	}
}
