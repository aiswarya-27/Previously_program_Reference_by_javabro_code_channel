package OOPs;

public class Abstraction_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Abstraction2 abstr=new Abstraction2();
		Abstraction2 abstr1=new Abstraction2();
	abstr.method();
	abstr1.sample();
		
	}

}
