package OOPs;

public class Constructor {
 int age;
 String address;

// inside bracket (int age,String address) --> it is called Parameter
Constructor(int age,String address){
	this.age =age;
	this.address=address;
}

 void human() {
	System.out.println("this method i am call here address:"+this.address);
	System.out.println("this method i am call here age:"+this.age);
}


}