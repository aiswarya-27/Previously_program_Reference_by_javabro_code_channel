package OOPs;

public class Constructor_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// (123,"Aishu") --------------> is called Argument
		Constructor obj =new Constructor(123,"Aishu");
		
		Constructor obj1 =new Constructor(1235,"saiAishu");
	// 12 to 17 line it is call textually represent
		System.out.println("age1:"+obj.age);
		
		System.out.println("age2:"+obj1.age);
		System.out.println("Address1:"+obj.address);
		
		System.out.println("Address2:"+obj1.address);
		
		System.out.println("");
		
		obj.human();
		obj1.human();
		
	}	
	

}
