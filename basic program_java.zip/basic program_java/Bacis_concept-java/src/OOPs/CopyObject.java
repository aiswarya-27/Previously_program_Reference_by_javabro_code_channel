package OOPs;

public class CopyObject {
	//attributes
	 int num;
	 String dasid;
	 double numbericavalue; 
 char letter;
	// parameter
CopyObject(int num,String dasid,double numbericavalue, char letter){
	this.setNum(num);
	this.setDasid1(dasid);
	this.setNumbericalvalue(numbericavalue);
	this.setLetter(letter);
}

public CopyObject(CopyObject xxx) {
	// TODO Auto-generated constructor stub
}

//here we have called the getter method
public int getNum() {
	return num;
}
public String getDasid1() {
	return dasid;
}
public double getNumbericalvalue() {
	return numbericavalue;
}
public char getLetter() {
	return letter;
}
// setter method 
public void setNum(int num) {
	this.num=num;
}

public void setDasid1(String dasid) {
	this.dasid=dasid;
}

public void setNumbericalvalue(double numbericavalue) {
	this.numbericavalue=numbericavalue;
}

public void setLetter(char letter) {
	this.letter=letter;
}

}
