package OOPs;

public class CopyObjectmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
CopyObject xxx= new CopyObject(123,"A7675",90.8,'&');
CopyObject xxx1= new CopyObject(7890,"79879hjk",688.0,'*');
xxx1.setDasid1("A8768769");
//System.out.println("xxx is 1st object name:"+xxx);
//System.out.println("xxx1 is 2nd object name:"+xxx1);


System.out.println("Num:"+xxx.num);
System.out.println("Dasid:"+xxx.dasid);
System.out.println("NumbercialValue:"+xxx.numbericavalue);
System.out.println("Char:"+xxx.letter);


System.out.println("Num:"+xxx1.num);
System.out.println("Dasid:"+xxx1.dasid);
System.out.println("NumbercialValue:"+xxx1.numbericavalue);
System.out.println("Char:"+xxx1.letter);

  // only print the address

	}

}
