package OOPs;

public class DynamicPolymorshim {
	
public void test() {
	// TODO Auto-generated method stub
	System.out.println("this test testing : DynamicPolymorshim  ");
}

public void sample() {
	// TODO Auto-generated method stub
	System.out.println("this sample testing : DynamicPolymorshim  ");
}

public void sample1() {
	// TODO Auto-generated method stub
	
}

public void sample2() {
	// TODO Auto-generated method stub
	
}



}
