package OOPs;

public class DynamicPolymorshim1 extends DynamicPolymorshim {
	public void sample1() {
		System.out.println("this sample1 testing : DynamicPolymorshim1 ");
	}
	public void sample2() {
		System.out.println("this sample2 testing : DynamicPolymorshim1 ");
	}
}
