package OOPs;

public class DynamicPolymorshim2 extends DynamicPolymorshim1 {

	
}
