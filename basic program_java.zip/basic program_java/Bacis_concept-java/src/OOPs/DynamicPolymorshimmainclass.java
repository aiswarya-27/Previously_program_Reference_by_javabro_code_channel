package OOPs;

import java.util.Scanner;

public class DynamicPolymorshimmainclass {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner =new Scanner( System.in);
		DynamicPolymorshim dynamiploy;
		
		System.out.println("Pls enter INTEGER data type  here");
		System.out.println("(1=DynamicPolymorshim1) or (2=DynamicPolymorshim2)");
		
		int mainsample =scanner.nextInt();
		
		if(mainsample==1) {
			dynamiploy=new DynamicPolymorshim1();
			dynamiploy.sample1();
			dynamiploy.sample2();
		}
		else if(mainsample==2) {
			dynamiploy=new DynamicPolymorshim2();
			dynamiploy.sample1();
			dynamiploy.sample2();
		}
		else if (mainsample >= 3 && mainsample <= 5) {
            System.out.println("Invalid integer data type entered");
		}
		else {
			System.out.println("in case you have print Integer types");
		}
		
		
		
		
	        scanner.close();
	}
				}
