package OOPs;

public class Encapsulation {
	
	//attributes 
private int number;
private String dasid;
private double numbericalvalue;


// inside backet (int number,String dasid, double numericalvalue)---. it is called Parameter
Encapsulation(int number,String dasid, double numbericalvalue){
	this.setNumbericalvalue(numbericalvalue);
	this.setNumber(number);
	this.setDasid(dasid);
}

	
public int getNumber() {
	return number;
}
public String getDasid() {
	return dasid;
}
public double getNumbericalvalue() {
	return numbericalvalue;
}

public void setNumber(int number) {
	this.number=number;
}
public void setDasid(String dasid) {
	this.dasid=dasid;
}
public void setNumbericalvalue(double numbericalvalue) {
	this.numbericalvalue=numbericalvalue;
}
}
