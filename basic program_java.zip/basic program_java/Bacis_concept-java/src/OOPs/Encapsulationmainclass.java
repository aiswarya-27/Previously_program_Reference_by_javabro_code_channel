package OOPs;

public class Encapsulationmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Encapsulation encap=new Encapsulation(123,"A868582",78.0);
System.out.println(encap.getNumber());
System.out.println(encap.getDasid());
System.out.println(encap.getNumbericalvalue());
// Modifying 'dasid' using setter
encap.setDasid("78969A");

// Printing updated values using getters
System.out.println("\nUpdated Values:");
System.out.println("Number: " + encap.getNumber());
System.out.println("DasID: " + encap.getDasid());
System.out.println("Numerical Value: " + encap.getNumbericalvalue());


	}

}
