package OOPs;

public class Inheritance1 {
// this my super call name Inheritance1
	
	// 7 and 8 line attributes name
	int age;
	String string;
	
	
	// method name : sample_inheritance
	void sample_inhertance(int age,String string) {
		this.age =age;
		this.string= string;
		
	}
}
