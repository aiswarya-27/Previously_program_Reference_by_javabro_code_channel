package OOPs;

public class Inheritance2 extends Inheritance1{
	// sub class name:Inheritance2
	// same variable i assign here
	int number11=78;
	String dasid="A8798595";


}
