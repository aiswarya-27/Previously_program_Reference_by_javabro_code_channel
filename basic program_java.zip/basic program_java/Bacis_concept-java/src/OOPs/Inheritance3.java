package OOPs;

public class Inheritance3 extends Inheritance1 {
	// sub class name:Inheritance3
	// same variable i assign here
int number11 =890;
String dasid="iunjn";
}
