package OOPs;

public class Inheritance_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inheritance2 objec= new Inheritance2();
		
		Inheritance3 object1= new Inheritance3();
		

		// method name : sample_inheritance
		objec.sample_inhertance(123, "Aishu sai");
		object1.sample_inhertance(123678, "Aishu Pramila");
		
		// texually repesent
		System.out.println("This my inheritance2 i have call here age:"+objec.age);
		System.out.println("This my inheritance2 i have call here String:"+objec.string);
		
		System.out.println("This my inheritance3 i have call here:"+object1.age);
		System.out.println("This my inheritance3 i have call here:"+object1.string);
		
		System.out.println("this my attributance using inheritance2 number11:"+objec.number11);
		System.out.println("this my attributance using inheritance2 dasid:"+objec.dasid);
		
		System.out.println("this my attributance using inheritance2 number11:"+object1.number11);
		System.out.println("this my attributance using inheritance3 dasid1:"+object1.dasid);
		
	}

}
