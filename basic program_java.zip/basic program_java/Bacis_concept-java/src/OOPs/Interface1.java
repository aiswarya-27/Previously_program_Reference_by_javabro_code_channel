package OOPs;

public class Interface1 implements Interface5_using_inteface {
// override wherever i will click inteface1 means it will give default come line no 7to `10
	//system.out.println is alos  needed
	@Override
	public void sample1() {
		// TODO Auto-generated method stub
		System.out.println("sample1 this my method name :messge reponse Testing the Interface5_using_inteface");
	}

	
}
