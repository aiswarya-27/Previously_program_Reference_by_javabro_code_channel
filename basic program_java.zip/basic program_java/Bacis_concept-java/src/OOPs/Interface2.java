package OOPs;

public class Interface2 implements Interface6_using_inteface {
	// override wherever i will click inteface2 means it will give default come line no 5to 9
	//system.out.println is alos  needed
	@Override
	public void sample2() {
		// TODO Auto-generated method stub
		System.out.println("sample2 this my method name :messge reponse Testing the Interface6_using_inteface");
	}

}
