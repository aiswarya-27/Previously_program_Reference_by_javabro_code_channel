package OOPs;

public class Interface3 implements Interface5_using_inteface{
	// override wherever i will click inteface3 means it will give default come line no 5to 9
	@Override
	public void sample1() {
		// TODO Auto-generated method stub
		
	}
	
}
