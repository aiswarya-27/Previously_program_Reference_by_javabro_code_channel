package OOPs;

public class Interface4 implements Interface5_using_inteface,Interface6_using_inteface{
	// override wherever i will click inteface4 means it will give default come line no 5to 15
	//system.out.println is alos  needed
	@Override
	public void sample2() {
		// TODO Auto-generated method stub
		System.out.println("testing the sample2");
	}

	@Override
	public void sample1() {
		// TODO Auto-generated method stub
		System.out.println("testing the sample1");
	}
	
}
