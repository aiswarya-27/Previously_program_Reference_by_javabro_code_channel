package OOPs;

public interface Interface5_using_inteface {
	// return types is need required
	//system.out.println is alos not needed
	void sample1();
	}
