package OOPs;

public interface Interface6_using_inteface {
	// like inheritance
	
	void sample2();
}
