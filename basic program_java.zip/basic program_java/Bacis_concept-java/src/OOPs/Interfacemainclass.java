package OOPs;

public class Interfacemainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Interface1 interface1 = new Interface1();
Interface2 interface2 = new Interface2();
Interface3 interface3 = new Interface3();
Interface4 interface4 = new Interface4();
interface4.sample1();
interface4 .sample2();

interface1.sample1();
interface2.sample2();
	}

}
