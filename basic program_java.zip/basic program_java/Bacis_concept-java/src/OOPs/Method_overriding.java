package OOPs;

public class Method_overriding {

	int dasid;
	String employee_details;
	
	int age;
	double Double;
	
	void sample1(int dasid,String employee_details) {
		this.dasid=dasid;
		this.employee_details= employee_details;
		System.out.println("this my sample 1 data:"+employee_details);
	}
	
	 String sample2(int age,double Double ) {
		 this.age=age;
		 this.Double= Double;
		 return "Age: " + age + ", Double Value: " + Double;
		
		
	}
	}
