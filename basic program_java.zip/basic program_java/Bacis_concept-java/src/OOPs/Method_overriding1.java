package OOPs;

public class Method_overriding1 extends Method_overriding{
	
@Override
void sample1(int dasid,String employee_details) {
		this.dasid=dasid;
		this.employee_details= employee_details;
	}
@Override
String sample2(int age,double Double ) {
	 this.age=age;
	 this.Double= Double;
	 return "Age: " + age + ", Double Value: " + Double;
}
	
}
