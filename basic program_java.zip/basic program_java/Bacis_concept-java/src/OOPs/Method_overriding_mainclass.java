package OOPs;

public class Method_overriding_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Method_overriding example = new Method_overriding();
		Method_overriding1 example1= new Method_overriding1();
		
	
	example.sample1(2345,"A868582dasid");
	
	example1.sample2(8,56.06);
	
System.out.println("dasid :"+example.dasid);
System.out.println("employee_details :"+example.employee_details);
System.out.println("age :"+example1.age);
System.out.println("Double:"+example1.Double);
//System.out.println(example.age);
		}

}
