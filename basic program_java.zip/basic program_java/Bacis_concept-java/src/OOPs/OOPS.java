package OOPs;

import java.util.ArrayList;

public class OOPS {
	
	//attributes
int age=90;
String string ="Aiswarya";
	void tomethod() {
		System.out.println("the data insert succefully");
	}
	 static void tomethod1() {
		 System.out.println("This my method name of tomethod1");
	 }
	 
	
	 
}
