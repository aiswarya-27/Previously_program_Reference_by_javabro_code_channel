package OOPs;

public class Overloaded_Constructor_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Overloaded_constructors constr = new Overloaded_constructors(345,"pramila");
	Overloaded_constructors constr1 = new Overloaded_constructors(678,"kousalya");
		
	// call variable name
		System.out.println("EmpId :"+constr.empid);
		System.out.println("Name1 :"+constr.name1);
		
		System.out.println("EmpId :"+constr1.empid);
		System.out.println("Name1 :"+constr1.name1);
		
		
		constr.names();
		constr1.names();
		
		
	}

}
