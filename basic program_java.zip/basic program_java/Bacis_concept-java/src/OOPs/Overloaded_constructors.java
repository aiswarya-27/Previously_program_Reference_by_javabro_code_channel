package OOPs;

public class Overloaded_constructors {


	 
	 int empid;
	 String name1;
	 
	// class name
	Overloaded_constructors(int empid){
		this.empid=empid;
		
	}
	
	Overloaded_constructors(int empid,String name1){
		this.empid=empid;
		this.name1=name1;
	}
	void names() {
		System.out.println("this my 1st object here i have call empid:"+this.empid);
		System.out.println("this my 2nd object here i have call name1:"+this.name1);
	}
	
}
