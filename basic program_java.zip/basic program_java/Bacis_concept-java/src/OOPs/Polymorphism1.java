package OOPs;

public class Polymorphism1 {
	
	public void sample() {
	System.out.println("The testing the sample for polymorphism1");
}
	public void anothersample() {
		System.out.println("The testing other sample ");
	}
}
