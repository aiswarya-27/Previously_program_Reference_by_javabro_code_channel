package OOPs;

public class Polymorphism3 extends Polymorphism1{
	// we have using Polymorphism1 call here , same method call here 
		// method name : sample
		//override is needed
	@Override
public void sample() {
	System.out.println("Reponse message polymorphism3:The testing the sample for polymorphism3");
}
	@Override
	public void anothersample() {
		System.out.println("Reponse message polymorphism3:The testing other sample  for anothersample in  polymorphism3");
	}
}
