package OOPs;

public class Polymorphism4 extends Polymorphism1{
	@Override
	public void sample() {
	System.out.println("Reponse message Polymorphism4: The testing the sample for polymorphism4");
	/***********This behavior demonstrates runtime polymorphism:

At runtime, the JVM determines whether the method being called has been overridden in the subclass.
If a subclass does not override a method, the inherited version from the parent class is used.

*******************************/
}
}
