package OOPs;

public class Polymorphismmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Polymorphism1 xxx1= new Polymorphism1();
		Polymorphism2 xxx= new Polymorphism2();
		Polymorphism3 yyy=new Polymorphism3();
		Polymorphism4 zzz=new Polymorphism4();
		
		Polymorphism1 [] mainPolymorphism = {xxx1,xxx,yyy,zzz};
		
	for(Polymorphism1 x:mainPolymorphism) {
		
		x.sample();
		
		x.anothersample();
	}
	}

}
