package OOPs;

public class Static_Keywords {

	int num;
	String string;
 static int numboffString;
	Static_Keywords (int num,String string ){
		this.num=num;
		this.string=string;
		numboffString++;
	}
}
