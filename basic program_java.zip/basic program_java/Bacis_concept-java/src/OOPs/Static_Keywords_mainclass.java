package OOPs;

public class Static_Keywords_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Static_Keywords sample= new Static_Keywords(123,"Aishu");
		Static_Keywords sample1= new Static_Keywords(678,"saiAishu");
		Static_Keywords sample2= new Static_Keywords(90,"pramila");
		
	System.out.println("count the object name:"+sample1.numboffString);
		
	}

}
