package OOPs;

public class Super_keywords1 {

	int num;
	String empdetails;
	char Char;
	// super  class name :Super_keywords1
	Super_keywords1(int num,String empdetails,char Char){
		this.num=num;
		this.empdetails=empdetails;
		this.Char=Char;
	}
	public String toString() {
		return num+"\n"+empdetails+"\n"+Char;
	}
}

