package OOPs;

public class Super_keywords2 extends Super_keywords1{
	// sub calss
	double Double;
	public char[] string;
	
	Super_keywords2(int num,String empdetails,char Char,double Double){
		super(num,empdetails,Char);
		this.num=num;
		this.empdetails=empdetails;
		this.Char=Char;
		this.Double=Double;
	}
	
	public String toString() {
		return super.toString()+" "+this.Double;
	}

}
