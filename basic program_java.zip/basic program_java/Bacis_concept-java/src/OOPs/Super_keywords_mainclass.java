package OOPs;

public class Super_keywords_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Super_keywords1 sample = new Super_keywords1(123,"A868582",'@');
	
	
	System.out.println("This my Super_keywords1 variable num:"+sample.num);
	System.out.println("This my Super_keywords1 variable empdetails:"+sample.empdetails);
	System.out.println("This my Super_keywords1 variable Char:"+sample.Char);
		
	
Super_keywords2 sample1 =new Super_keywords2(23,"Pramilaaishu",'M',13.7);
	
System.out.println(sample1.toString());
	}

}
