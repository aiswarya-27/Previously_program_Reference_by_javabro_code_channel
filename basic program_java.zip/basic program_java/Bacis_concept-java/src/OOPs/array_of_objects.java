package OOPs;

public class array_of_objects {
int age;
int num;
String dasid;
	
	array_of_objects(int age,int num,String dasid){
		this.age= age;
		this.num=num;
		this.dasid=dasid;
	}
}
