package OOPs;

public class array_of_objects_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//array_of_objects[] data= new array_of_objects[3];
		
		array_of_objects array_of_objects1 =new array_of_objects(123,567,"aishu");
		array_of_objects array_of_objects2 =new array_of_objects(456,908,"saiaishu");
		array_of_objects array_of_objects3 =new array_of_objects(688,345,"pramila");
		
		array_of_objects[] data1 = {array_of_objects1,array_of_objects2,array_of_objects3};
		
		//data[0]=array_of_objects1;
		//data[1]=array_of_objects2;
		//data[2]=array_of_objects3;
		
		
		//System.out.println(data[0].age);
		//System.out.println(data[0].num);
		//System.out.println(data[0].dasid);
		
		System.out.println(data1[0].age);
		System.out.println(data1[1].num);
		System.out.println(data1[2].dasid);
		
		
		System.out.println(data1[1].age);
		System.out.println(data1[1].num);
		System.out.println(data1[1].dasid);
		
		
	}

}
