package OOPs;

public class object_passing1 {
int number;
	object_passing1(int number){
		this.number= number;
	}
	
}
