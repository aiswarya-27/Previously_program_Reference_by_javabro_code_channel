package OOPs;

public class object_passing2 {
	//private static String number;

	 void tomethod(object_passing1 obj1) {
		System.out.println("this my sample method: "+obj1.number);
	}
}
