package OOPs;

public class object_passing_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  object_passing1 obj1 = new  object_passing1(12389);

	        // Creating an object of object_passing2
		  object_passing2 obj2 = new  object_passing2();

	        // Passing obj1 to the method of obj2
	        obj2.tomethod(obj1);
		
		
	}

}
