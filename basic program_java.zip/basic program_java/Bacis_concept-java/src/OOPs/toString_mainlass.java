package OOPs;

public class toString_mainlass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
tostring sample = new tostring();
tostring sample1 = new tostring();
tostring sample2 = new tostring();
// Explicitly call the custom method
System.out.println("Explicit details:\n" + sample.getDetails());
System.out.println("");

// Implicitly call the overridden toString() method
System.out.println("Implicitly Using toString():\n" + sample.tostring1());
System.out.println("");

//textually represents
System.out.println("call variable Using age:\n" + sample.age);
System.out.println("");

System.out.println("call variable Using  address:\n" + sample.address);
System.out.println("");
sample2.method();
	}

}
