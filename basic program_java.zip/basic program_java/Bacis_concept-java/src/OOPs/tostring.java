package OOPs;

public class tostring {
// attributes
	int age=325;
	String address="65a xx,uuu.";
	
	 // Custom method to return object details
	//getDetails :method
 public String getDetails() {
        return "Age: " + age + "\nAddress: " + address;
    }
	//tostring1()
	public String tostring1() {
		//System.out.println("this my data tostring1");
		return age+"\n"+address;
		
	}
	public void method() {
		System.out.println("this my method name"+address);
	}
	

}
