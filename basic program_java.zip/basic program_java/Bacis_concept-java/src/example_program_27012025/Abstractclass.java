package example_program_27012025;

public abstract class Abstractclass {

	abstract void method();
	
	abstract void process();
	
}
