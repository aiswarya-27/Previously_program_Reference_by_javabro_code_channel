package example_program_27012025;

public class Abstractclass1 extends Abstractclass {

	@Override
	void method() {
		// TODO Auto-generated method stub
		System.out.println("This my Abstractclass1 of method");
	}

	@Override
	void process() {
		System.out.println("this my Abstractclass1 of process");
	}


}
