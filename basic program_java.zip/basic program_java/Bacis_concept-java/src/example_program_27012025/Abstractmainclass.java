package example_program_27012025;

public class Abstractmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Abstractclass1 a= new Abstractclass1();
a.method();
a.process();


	}

}
