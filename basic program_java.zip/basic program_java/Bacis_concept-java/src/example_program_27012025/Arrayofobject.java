package example_program_27012025;

public class Arrayofobject {

	String name;
	int age;
	double d;
	
	Arrayofobject(String name,int age,double d){
		this.name= name;
		this.age=age;
		this.d=d;
	}
}
