package example_program_27012025;

public class Arrayofobjectmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
Arrayofobject [] a=new Arrayofobject[3];

Arrayofobject a1=new Arrayofobject("Aishu",78,67.89);
Arrayofobject a2=new Arrayofobject("Aishusai",7,6.5);
Arrayofobject a3=new Arrayofobject("AishuPramila",6,90.6);

a[0]=a1;
a[1]=a2;
a[2]=a3;

System.out.println(a[0].name);
System.out.println(a[1].name);
System.out.println(a[2].name);

System.out.println(a[0].age);
System.out.println(a[1].age);
System.out.println(a[2].age);

System.out.println(a[0].d);
System.out.println(a[1].d);
System.out.println(a[2].d);

*/
	
		Arrayofobject a1=new Arrayofobject("Aishu",78,67.89);
		Arrayofobject a2=new Arrayofobject("Aishusai",7,6.5);
		Arrayofobject a3=new Arrayofobject("AishuPramila",6,90.6);
		
		Arrayofobject[]a = {a1,a2,a3};
		
		System.out.println(a[0].name);
		System.out.println(a[1].name);
		System.out.println(a[2].name);

		System.out.println(a[0].age);
		System.out.println(a[1].age);
		System.out.println(a[2].age);

		System.out.println(a[0].d);
		System.out.println(a[1].d);
		System.out.println(a[2].d);
		

	}

}
