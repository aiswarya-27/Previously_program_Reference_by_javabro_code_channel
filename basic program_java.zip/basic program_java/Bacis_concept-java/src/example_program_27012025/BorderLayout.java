package example_program_27012025;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;

public class BorderLayout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Border border= BorderFactory.createLineBorder(Color.DARK_GRAY);
		JFrame s= new JFrame();
		s.getContentPane().setBackground(Color.white);
		s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		s.setLayout(new java.awt.BorderLayout());
		
       

		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();
		JPanel panel5= new JPanel();
		
		panel1.setPreferredSize(new Dimension(30, 30));
		panel2.setPreferredSize(new Dimension(30, 30));
		panel3.setPreferredSize(new Dimension(30, 30));
		panel4.setPreferredSize(new Dimension(30, 30));
		panel5.setPreferredSize(new Dimension(30, 30));
		
		
		 // Add panels to different regions of the BorderLayout
        s.add(panel1, java.awt.BorderLayout.NORTH);
        s.add(panel2, java.awt.BorderLayout.SOUTH);
        s.add(panel3, java.awt.BorderLayout.WEST);
        s.add(panel4, java.awt.BorderLayout.EAST);
        s.add(panel5, java.awt.BorderLayout.CENTER);

        s.setVisible(true);
		
		
		panel1.setBackground(Color.black);
		panel2.setBackground(Color.gray);
		panel3.setBackground(Color.ORANGE);
		panel4.setBackground(Color.yellow);
		panel5.setBackground(Color.green);
	}

}
