package example_program_27012025;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Buttonclass extends Buttonmainclass implements ActionListener{
	JFrame frame;
	JLabel label;
	JButton button ;
	Buttonclass(){
		frame = new JFrame();
		 button = new JButton("Click Me");
		 label =new JLabel();
		 
		 frame.getContentPane().setBackground(Color.GREEN);

		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setBounds(250, 250, 400, 400); // Increased size for better visibility
	    frame.setLayout(null);
		frame.setTitle("This my sample button cases");
		frame.add(button);
		frame.add(label);
		
		
		label.setBackground(Color.BLUE);
		label.setOpaque(true);
		//label.setLayout(null);
		 label.setBounds(100, 200, 200, 30);
		label.setText("This my inside the label");
		label.setHorizontalTextPosition(JLabel.CENTER);
		label.setVerticalTextPosition(JLabel.CENTER);
		
		 // Initialize JButton and set properties
	    button.setBounds(100, 100, 150, 50);
	    button.addActionListener(this); // Add action listener to button
	
				
		}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			System.out.println("sample button");
		}
		
	}

}
