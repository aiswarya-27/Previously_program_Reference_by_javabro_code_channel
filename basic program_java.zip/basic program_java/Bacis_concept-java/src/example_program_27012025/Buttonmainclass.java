package example_program_27012025;

import javax.swing.JFrame;

public class Buttonmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Buttonclass button =new Buttonclass();
			
		
	}

}
