package example_program_27012025;

public class Constructor {

	int age;
	String name;
	double d;
	char c;
	
	void add(int age,String name,double d,char c){
		this.age=age;
		this.name=name;
		this.d=d;
		this.c=c;
	
	}
	
	void sample() {
		System.out.println("this my age details:"+this.age);
	}
	void test() {
		System.out.println("this my char details:"+this.c);
	}

	  // Method to assign values manually
    void setValues(int age, String name, double d, char c) {
        this.age = age;
        this.name = name;
        this.d = d;
        this.c = c;
    }
}
