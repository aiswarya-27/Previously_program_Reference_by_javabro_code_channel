package example_program_27012025;

public class Constructormainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Constructor a=new Constructor();
a.add(78, "sai", 56.3, '#');

System.out.println("age :"+a.age);
System.out.println("name :"+a.name);
System.out.println("double :"+a.d);
System.out.println("char :"+a.c);


Constructor a1=new Constructor();
a1.setValues(25, "John", 45.2, '*');  // Assigning values manually
a1.sample();
System.out.println("Updated Age from default constructor: " + a1.age);


Constructor a2=new Constructor();
a2.setValues(0, "None", 0.0, '&');  // Assigning a value to char
a2.test();
System.out.println("Updated Char from default constructor: " + a2.c);
	}

}
