package example_program_27012025;

import java.util.Scanner;

public class DynamicPloymainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);

System.out.println("This my interger data types here");
System.out.print("(1=one) or(10=ten):");

int a=scanner.nextInt();
DynamicPoly1 dynamic;

if(a==1) {
	dynamic =new DynamicPoly2();
	dynamic.test();
	dynamic.sample();
}else if(a ==10){
	dynamic =new DynamicPoly3();
	dynamic.test();
	dynamic.sample();
	
}else {
	dynamic= new DynamicPoly1();
	dynamic.sample();
	dynamic.test();
	System.out.println("here we have call method");
}
scanner.close();
	}

}
