package example_program_27012025;

public class DynamicPoly1 {

	void test() {
		System.out.println("this my test");
	}
	void sample() {
		System.out.println("this my sample");
	}
}
