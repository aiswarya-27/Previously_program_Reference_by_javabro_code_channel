package example_program_27012025;

public class DynamicPoly2 extends DynamicPoly1{
@Override
	void test() {
		System.out.println("this my test : DynamicPoly2");
	}
	void sample() {
		System.out.println("this my sample :DynamicPoly2 ");
	}
}
