package example_program_27012025;

public class DynamicPoly3 extends DynamicPoly1 {
	@Override
	void test() {
		System.out.println("this my test : DynamicPoly3");
	}
	void sample() {
		System.out.println("this my sample :DynamicPoly3");
	}
}
