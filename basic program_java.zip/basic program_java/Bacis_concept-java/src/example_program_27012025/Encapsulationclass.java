package example_program_27012025;

public class Encapsulationclass {

	String name;
	int age;
	char c;
	
	Encapsulationclass(String name,int age,char c){
		/* get value
		this.name=name;
		this.age=age;
		this.c=c;
		*/
		//set value
		
		this.setName1(name);
		this.setAge1(age);
		this.setC1(c);
	}
	
	public String getName() {
		return name;
		
	}
	public int getAge() {
		return age;
		
	}
	public char getC() {
		return c;
		
	}

	public void setC1(char c) {
		// TODO Auto-generated method stub
		this.c=c;
	}
	
	public void setName1(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}
	public void setAge1(int age) {
		// TODO Auto-generated method stub
		this.age=age;
	}
}
