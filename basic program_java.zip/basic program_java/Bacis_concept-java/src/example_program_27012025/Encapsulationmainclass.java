package example_program_27012025;

public class Encapsulationmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulationclass e= new Encapsulationclass("Aishu",34,'&');
		
		e.setC1('*');
		System.out.println(e.getName());
		System.out.println(e.getAge());
		System.out.println(e.getC());
		
		
	}

}
