package example_program_27012025;

import java.util.Scanner;

public class Exceptionhandlingmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner( System.in);
		
		
		try {
			//System.out.print("kindly enter pls");	
			
		System.out.print("This interger data Types here");	
		int a=scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.print("this my reference data types here");
		String name=scanner.next();
		
		scanner.nextLine();
		
		System.out.print("This my primitive data types here : double");
		Double d=scanner.nextDouble();
		
		}
		
		catch(Exception e) {
			System.out.println("Invalid data entered. Please enter correct data types.");;
		}
		finally{
			
			scanner.close();
		}
	}

}
