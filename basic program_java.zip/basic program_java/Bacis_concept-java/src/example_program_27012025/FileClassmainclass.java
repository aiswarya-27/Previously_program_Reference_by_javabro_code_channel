package example_program_27012025;

import java.io.File;

public class FileClassmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//File file =new File("C://BGV_BackEnd//Bacis_concept-java//Aiswarya_WIFI_Bill.docx");
		File file =new File("C://BGV_BackEnd//Bacis_concept-java//Aiswarya_WIFI_Bill.pdf");
if(file.exists()) {
	System.out.println(file.getAbsolutePath());
	System.out.println(file.getName());
	System.out.println(file.getPath());
	System.out.println(file.isFile());
	//file.delete();
	
}
else {
	System.out.println("Invaild data");
}
	}

}
