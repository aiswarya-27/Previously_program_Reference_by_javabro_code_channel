package example_program_27012025;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReadermainclass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

	try {
		FileReader reader=new FileReader("sample.txt");
		int data =reader.read();
		while(data !=-1) {
			System.out.print((char) data);
			data =reader.read();
		}
		reader.close();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	


	}

}
