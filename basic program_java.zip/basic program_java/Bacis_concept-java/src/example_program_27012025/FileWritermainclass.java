package example_program_27012025;

import java.io.FileWriter;
import java.io.IOException;

public class FileWritermainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      try {
	            FileWriter writer = new FileWriter("sample05022025.txt");
	            FileWriter writer1 = new FileWriter("Test_05022025.txt");

	            writer.write("Hi Aiswarya,\nThis is your WiFi claim details.\nRegards,\nAiswarya.");
	            writer1.write("This is my WiFi claim details.\n");
	            writer1.append("Thanks and regards.");

	            writer.close();
	            writer1.close();

	            System.out.println("Files written successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}