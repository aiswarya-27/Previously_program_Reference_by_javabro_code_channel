package example_program_27012025;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class FlowLayout {
JButton button;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
JFrame frame= new JFrame();

frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setBounds(50, 50, 50, 50);
frame.getContentPane().setBackground(Color.green);
//Correct way to set FlowLayout
//frame.setLayout(new FlowLayout(FlowLayout.CENTER));
frame.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));


JPanel panel =new JPanel();
panel.add( new JButton("1"));
panel.add( new JButton("2"));
panel.add( new JButton("3"));
panel.add( new JButton("4"));
panel.add( new JButton("5"));
panel.add( new JButton("6"));
panel.add( new JButton("7"));
panel.add( new JButton("8"));

frame.add(panel);
frame.setVisible(true);

	}
	

}
