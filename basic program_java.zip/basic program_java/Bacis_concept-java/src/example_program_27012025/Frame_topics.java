package example_program_27012025;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Frame_topics implements ActionListener{
	JButton button ;
	JFrame frame ;

	
	 Frame_topics() {
		// TODO Auto-generated method stub
		frame = new JFrame("Example Frame");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.getContentPane().setBackground(Color.GREEN);
frame.setBounds(100, 100, 400, 400); // Increased size for better layout
frame.setLayout(null);


JLabel b= new JLabel();
b.setBackground(Color.YELLOW);
b.setBounds(50, 50, 250, 250);
b.setOpaque(true);

//b.setIcon(Icon.geticon);

JPanel c= new JPanel();
c.setBounds(50, 320, 300, 50);
c.setBackground(Color.BLUE);
c.setLayout(null);

ImageIcon icon= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
b.setIcon(icon);

Border order = BorderFactory.createLineBorder(Color.orange,3);
b.setBorder(order);

button = new JButton("click me");
button.setBounds(120, 10, 100, 30);
button.addActionListener(this);
c.add(button);

frame.add(b);
frame.add(c);
//frame.add(i);
//frame.add(order);

frame.setVisible(true);



	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			System.out.println("This my sample button");
		}
	}
	
	  public static void main(String[] args) {
	        new Frame_topics(); // Creating an instance of Frame_topics
	        
	        
	    }
	}


