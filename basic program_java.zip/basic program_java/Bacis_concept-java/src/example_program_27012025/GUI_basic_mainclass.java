package example_program_27012025;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class GUI_basic_mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner=new Scanner(System.in);
	
		String name =JOptionPane.showInputDialog("Enter your name");
		JOptionPane.showInputDialog("Hello", name);
		
		int age =Integer.parseInt(JOptionPane.showInputDialog("Enter your age"));
		JOptionPane.showInputDialog(null,"this is your age",age);
		
		float f=Float.parseFloat(JOptionPane.showInputDialog("Enter your float value here"));
		JOptionPane.showInputDialog(null,"this is your float value",f);
}

}
