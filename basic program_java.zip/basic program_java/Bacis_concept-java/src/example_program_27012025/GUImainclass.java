package example_program_27012025;

import java.awt.Color;
import java.awt.Frame;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GUImainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
JFrame a=new JFrame();

a.setSize(670, 500);
a.setTitle("test sample image");
a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
a.setResizable(false);


ImageIcon i=new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");

a.setIconImage(i.getImage());



JLabel label1 = new JLabel();
label1.setBackground(Color.black);
label1.setBounds(70, 50, 200, 200);
label1.setOpaque(true);

label1.setIcon(i);


a.add(label1);
a.setVisible(true);
//a.getContentPane().setBackground(Color.BLACK);  // background color change
//a.getContentPane().setBackground(new Color(56,0,8));  // background color change
//a.getContentPane().setBackground(new Color(219, 112, 147));  // HTML Color Names (RGB Code)
//a.getContentPane().setBackground(new Color(0xCD5C5C));  // HTML Color Names (Hex Code)  u need write the 0x is required


		
		
	}

}
