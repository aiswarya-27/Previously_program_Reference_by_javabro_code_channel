package example_program_27012025;


/* generic class how pass the single Parmeter******************/
/*
public class GenericClass <Thing>{
	
	Thing x;
	
	GenericClass(Thing x){
		this.x=x;
	}
public Thing getValue() {
	return x;
	
}
}
*/

/***********Generic class how pass the multi Parameter*****************/
/*
public class GenericClass <Thing,Thing1>{
	
	Thing x;
	Thing1 y;
	
	GenericClass(Thing x,Thing1 y){
		this.x =x;
		this.y=y;
	}
	
	// xvalue
	public Thing1 getValue() {
		return y;
		
	}
	//y value
	public Thing getValue1() {
		return x;
		
	}
	
}
*/

/*********** Bounded types***********/
public class GenericClass <Thing extends Number,Thing1 extends Number>{
	
	Thing x;
	Thing1 y;
	
	GenericClass(Thing x,Thing1 y){
		this.x =x;
		this.y=y;
	}
	
	// xvalue
	public Thing1 getValue() {
		return y;
		
	}
	//y value
	public Thing getValue1() {
		return x;
		
	}
	
}
