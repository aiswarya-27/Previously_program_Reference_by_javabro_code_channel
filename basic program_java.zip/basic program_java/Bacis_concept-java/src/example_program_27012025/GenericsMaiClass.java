package example_program_27012025;

public class GenericsMaiClass {
	
	/***************** display array value***************/
	/*
	public static void main(String[] args) { 
		
		 // Integer array
      Integer[] intArray = {1, 2, 3, 4};
      // Double array
      Double[] doubleArray = {2.4, 8.2, 4.3};
      // Character array
      Character[] charArray = {'a', 's', 'i', 'w'};
      // String array
      String[] stringArray = {"Aishu", "Pramila", "R"};
      
      // Calling the generic method
      displayArray(intArray);
      displayArray(doubleArray);
      displayArray(charArray);
      displayArray(stringArray);
      
	}
	public static void displayArray(Integer[] array) {
		for(Integer x: array) {
			System.out.print(x+"");
		}
		System.out.println();
	}
	
	public static void displayArray(Double[] array) {
		for(Double x: array) {
			System.out.print(x+"");
		}
		System.out.println();
	}
	
	public static void displayArray(Character[] array) {
		for(Character x: array) {
			System.out.print(x+"");
		}
		System.out.println();
	}
	
	public static void displayArray(String[] array) {
		for(String x: array) {
			System.out.print(x+"");
		}
		System.out.println();
	}
}
*/
	
/********************** using generic bacis prgram*************/
/*
public static void main(String[] args) { 
	
	 // Integer array
    Integer[] intArray = {1, 2, 3, 4};
    // Double array
    Double[] doubleArray = {2.4, 8.2, 4.3};
    // Character array
    Character[] charArray = {'a', 's', 'i', 'w'};
    // String array
    String[] stringArray = {"Aishu", "Pramila", "R"};
    
    
 // Calling the generic method
    displayArray(intArray);
    displayArray(doubleArray);
    displayArray(charArray);
    displayArray(stringArray);
    
}

 // Generic method to display arrays of any type

    public static <T> void displayArray(T[] array) {
    	for(T x:array) {
    		System.out.print(x+" ");
    	}
    	System.out.println();// New line after printing all elements
    
}
}

*/


/************ generic class in out put what are input i will give that all data type should the console itself*****/
/*
public static void main(String[] args) { 
	
	 // Integer array
   Integer[] intArray = {1, 2, 3, 4};
   // Double array
   Double[] doubleArray = {2.4, 8.2, 4.3};
   // Character array
   Character[] charArray = {'a', 's', 'i', 'w'};
   // String array
   String[] stringArray = {"Aishu", "Pramila", "R"};
   
   // Calling the generic method
   displayArray(intArray);
   displayArray(doubleArray);
   displayArray(charArray);
   displayArray(stringArray);
   
}

 // Generic method to display arrays of any type
    public static <Thing> void displayArray(Thing[] array) {
    	for(Thing x:array) {
    		System.out.print(x+" ");
    	}
    	System.out.println();// New line after printing all elements
    

    }
}
*/


	/*
	//get the data from what are input i will give me that array  first print A[0] in output 
	public static void main(String[] args) {
        // Integer array
        Integer[] intArray = {1, 2, 3, 4};
        // Double array
        Double[] doubleArray = {2.4, 8.2, 4.3};
        // Character array
        Character[] charArray = {'a', 's', 'i', 'w'};
        // String array
        String[] stringArray = {"Aishu", "Pramila", "R"};
        
        System.out.println(getFirst(intArray));
        System.out.println(getFirst(doubleArray));
        System.out.println(getFirst(charArray));
        System.out.println(getFirst(stringArray));
	}
        
        public static <Thing> void displayArray(Thing[] array) {
        	for(Thing x:array) {
        		System.out.print(x+" ");
        	}
        	System.out.println();// New line after printing all elements
        
	}
        public static<Thing> Thing getFirst(Thing[] array) {
        	return array[0];
        }
        
}

*/
        
	/******************** generics basic without for loop**************/
	
	/*
	public static void main(String[] args) {
		
		Player a=new Player();
		Games b= new Games();
		Trees c= new Trees();
		Sample d=new Sample();
		
		draw(a);
		draw(b);
		draw(c);
		draw(d);
		
		
	}
	public static <Thing> void draw(Thing x) {
		x.draw();
	}
}
*/
	
	/************generics class************/
	
	public static void main(String[] args) {
		/****************GenericsMyIntegerClass,GenericMyDoubleClass,GenericsMyCharacterClass,GenericsMyStringClass this function we will implmented here**********/
		/*
		GenericsMyIntegerClass myInt = new GenericsMyIntegerClass(1);
		GenericsMyDoubleClass myDouble = new GenericsMyDoubleClass(3.23);
		GenericsMyCharacterClass myChar= new GenericsMyCharacterClass('M');
		GenericsMyStringClass myString= new GenericsMyStringClass("S");
		
		
		System.out.println(myInt.getValue());
		System.out.println(myDouble.getValue());
		System.out.println(myChar.getValue());
		System.out.println(myString.getValue());
		*/
		
		/********** this program we have using the GenericsClass************/
		/** single variable we will call this function************/
		/*
		GenericClass<Integer> myInt = new GenericClass<>(1);
		GenericClass<Double> myDouble = new GenericClass<>(3.23);
		GenericClass<Character> myChar= new GenericClass<>('M');
		GenericClass<String> myString= new GenericClass<>("S");
		
		
		System.out.println(myInt.getValue());
		System.out.println(myDouble.getValue());
		System.out.println(myChar.getValue());
		System.out.println(myString.getValue());
		*/
		
		/***** multi variable we will call this function below********/
		/*
		GenericClass<Integer,Integer> myInt = new GenericClass<>(1,2);
		GenericClass<Double,Double> myDouble = new GenericClass<>(3.23,3.14);
		GenericClass<Character,Character> myChar= new GenericClass<>('M','S');
		GenericClass<String,Character> myString= new GenericClass<>("Hello",'*');
		
		
		System.out.println(myInt.getValue());
		System.out.println(myDouble.getValue());
		System.out.println(myChar.getValue());
		System.out.println(myString.getValue());
		
		System.out.println();
		
		System.out.println(myInt.getValue1());
		System.out.println(myDouble.getValue1());
		System.out.println(myChar.getValue1());
		System.out.println(myString.getValue1());
		*/
		
		/*************Bounded types************/
		GenericClass<Integer,Integer> myInt = new GenericClass<>(1,2);
		GenericClass<Double,Double> myDouble = new GenericClass<>(3.23,3.14);
		
		System.out.println(myInt.getValue());
		System.out.println(myDouble.getValue());
		
        System.out.println();
		
		System.out.println(myInt.getValue1());
		System.out.println(myDouble.getValue1());
		
		
	}
	
}
	
	
    
       