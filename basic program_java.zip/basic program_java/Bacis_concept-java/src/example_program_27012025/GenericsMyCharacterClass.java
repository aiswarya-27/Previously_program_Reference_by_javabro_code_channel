package example_program_27012025;

public class GenericsMyCharacterClass {
	Character x;
	
	GenericsMyCharacterClass (Character x){
		this.x=x;
	}
	public Character getValue() {
		return x;
		
	}
}
