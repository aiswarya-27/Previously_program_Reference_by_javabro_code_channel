package example_program_27012025;

public class GenericsMyDoubleClass {

	Double x;
	
	GenericsMyDoubleClass (Double x){
		this.x=x;
	}
	public Double getValue() {
		return x;
		
	}
	
}
