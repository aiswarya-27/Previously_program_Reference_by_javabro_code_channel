package example_program_27012025;

public class GenericsMyIntegerClass {
	Integer x;
	
	GenericsMyIntegerClass (Integer x){
		this.x=x;
	}
	public Integer getValue() {
		return x;
		
	}
}
