package example_program_27012025;

public class GenericsMyStringClass {
	String x;
	
	GenericsMyStringClass (String x){
		this.x=x;
	}
	public String getValue() {
		return x;
		
	}
}
