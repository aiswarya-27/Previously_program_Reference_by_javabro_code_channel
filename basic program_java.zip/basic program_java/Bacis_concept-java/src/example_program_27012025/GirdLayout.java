package example_program_27012025;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GirdLayout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JButton button;
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  frame.setBounds(100, 100, 100, 100); // Increased size for visibility
		frame.getContentPane().setBackground(Color.BLUE);
		 // Set GridLayout with a proper row x column count
        frame.setLayout(new GridLayout(3, 3)); // 3 rows, 3 columns (adjust as needed)
		
	
		
		
		frame.add(new JButton("1"));
		frame.add(new JButton("2"));
		frame.add(new JButton("3"));
		frame.add(new JButton("4"));
		frame.add(new JButton("5"));
		frame.add(new JButton("6"));
		frame.add(new JButton("7"));
		frame.add(new JButton("8"));
		frame.add(new JButton("9"));
		frame.add(new JButton("10"));
		
		//frame.add();
		frame.setVisible(true);
		
	}

}
