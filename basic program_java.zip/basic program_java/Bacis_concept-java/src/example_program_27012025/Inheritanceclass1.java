package example_program_27012025;

public class Inheritanceclass1 {


	

	public boolean method() {
		System.out.println("this my method inheritance1:");
		return false;
	
	}
}
