package example_program_27012025;

public class Inheritanceclass2 extends Inheritanceclass1{


	
		public boolean method() {
		System.out.println("this my method inheritance2 and inheritance1 :");
		return false;
	}
	
}
