package example_program_27012025;

public class Inheritanceclass3 {
	int age=78;
	String name="Aishu";
	char c='@';

}
