package example_program_27012025;

public class Inheritanceclass4 {
	int age=8;
	String name="Aishusai";
	char c='#';

}
