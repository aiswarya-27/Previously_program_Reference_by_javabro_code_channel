package example_program_27012025;

public class Inheritancemainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

Inheritanceclass1 i= new Inheritanceclass1();
i.method();


Inheritanceclass3 i1=new Inheritanceclass3();

System.out.println("this my inheritance3 in age:"+i1.age);
System.out.println("this my inheritance3 in name:"+i1.name);
System.out.println("this my inheritance3 in Character:"+i1.c);

Inheritanceclass4 i2=new Inheritanceclass4();
System.out.println("this my inheritance4 in age:"+i2.age);
System.out.println("this my inheritance4 in name:"+i2.name);
System.out.println("this my inheritance4 in Character:"+i2.c);


	}

}
