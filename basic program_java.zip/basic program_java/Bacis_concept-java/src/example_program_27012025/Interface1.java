package example_program_27012025;

public class Interface1 implements Interfaceclass5{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("this my interface5 value of test method");
	}

	@Override
	public void sample() {
		// TODO Auto-generated method stub
		System.out.println("this my interface5 value of sample ");
	}
	

}
