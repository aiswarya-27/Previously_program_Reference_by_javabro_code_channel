package example_program_27012025;

public class Interface2 implements Interface6{

	@Override
	public void sample1() {
		// TODO Auto-generated method stub
		System.out.println("this my interface6 value of sample1 mathod");
	}

	@Override
	public void test1() {
		// TODO Auto-generated method stub
		System.out.println("this my interface6 value of test1 mathod");
	}

}
