package example_program_27012025;

public class Interface3 implements Interface6{

	@Override
	public void sample1() {
		// TODO Auto-generated method stub
		System.out.println("this my interface6 and interface3 value of sample1 mathod");
	}

	@Override
	public void test1() {
		// TODO Auto-generated method stub
		System.out.println("this my interface6 and interface3 value of test1 mathod");
	}

}
