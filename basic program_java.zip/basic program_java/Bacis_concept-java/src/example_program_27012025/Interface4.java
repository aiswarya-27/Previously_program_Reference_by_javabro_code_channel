package example_program_27012025;

public class Interface4 implements Interfaceclass5,Interface6{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("tested");
	}

	@Override
	public void sample() {
		// TODO Auto-generated method stub
		System.out.println("sampled");
	}

	@Override
	public void sample1() {
		// TODO Auto-generated method stub
	System.out.println("sampled1")	;
	}

	@Override
	public void test1() {
		// TODO Auto-generated method stub
		System.out.println("test1");
	}

}
