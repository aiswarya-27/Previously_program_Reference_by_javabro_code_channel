package example_program_27012025;

public interface Interface6 {
// body is not mandatory
	
	void sample1();
	void test1();
	
	public static  void method() {
		
	}
}
