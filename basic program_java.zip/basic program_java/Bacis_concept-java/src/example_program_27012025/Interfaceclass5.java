package example_program_27012025;

public interface Interfaceclass5 {

	// body not required
	void test();
	void sample();
}
