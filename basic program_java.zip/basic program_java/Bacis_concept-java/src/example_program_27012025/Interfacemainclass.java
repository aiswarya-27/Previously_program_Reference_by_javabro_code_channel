package example_program_27012025;

public class Interfacemainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Interface1 i1= new Interface1();
i1.test();
i1.sample();

Interface2 i2= new Interface2();
i2.sample1();
i2.test1();

Interface3 i3= new Interface3();
i3.sample1();
i3.test1();

Interface4 i5= new Interface4();
i5.sample();
i5.sample1();
i5.test();
i5.test1();
	}

}
