package example_program_27012025;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class JTextFileclass  extends JtextFilemainclass implements ActionListener{
	
	JTextField textfield;
	JButton buttons;
	JFrame frame;

	
	JTextFileclass(){
		
	frame = new JFrame("This is the Label Page"); // ✅ Initialize JFrame

	        frame.setSize(400, 200); // ✅ Set a visible window size
	        frame.setLayout(new FlowLayout());
     
		
		buttons = new JButton("Click me");
		buttons.addActionListener(this);
		
		textfield= new JTextField();
		textfield.setBackground(Color.green);
		textfield.setPreferredSize(new Dimension(250,40));
		textfield.setCaretColor(Color.white);
		textfield.setFont(new Font("Consolas",Font.PLAIN,25));
		textfield.setText("Password");
		
		
		frame.add(buttons);
		frame.add(textfield);
		
		frame.setVisible(true);
	}






	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if( e.getSource()==buttons) {
			buttons.setEnabled(false);
			textfield.setEditable(false);
			System.out.println("this my sample in JTextfield" +textfield.getText());
		}
	}
	
	
}
