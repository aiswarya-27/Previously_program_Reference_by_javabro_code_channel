package example_program_27012025;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class JoptionPanemainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JOptionPane.showInternalMessageDialog(null, "sample page in JoptionPane error message ", "Error Messge", JOptionPane.ERROR_MESSAGE);
		
		JOptionPane.showInternalMessageDialog(null, "sample page in Joptionpane information mesaage", "Information mesaage", JOptionPane.INFORMATION_MESSAGE);
		JOptionPane.showInternalMessageDialog(null, "sample page in Joptionpane WARNING_MESSAGE", "WARNING_MESSAGE", JOptionPane.WARNING_MESSAGE);
		JOptionPane.showInternalMessageDialog(null, "sample page in Joptionpane QUESTION_MESSAGE", "QUESTION_MESSAGE", JOptionPane.QUESTION_MESSAGE);
		JOptionPane.showInternalMessageDialog(null, "sample page in Joptionpane PLAIN_MESSAGE", "PLAIN_MESSAGE", JOptionPane.PLAIN_MESSAGE);
		
		 ImageIcon icon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png"); // Provide the correct path
		 JOptionPane.showConfirmDialog(null, "sample page", "i love murugan ",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE, 
	            icon);

	}

}
