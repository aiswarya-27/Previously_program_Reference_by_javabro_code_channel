package example_program_27012025;

public class JtextFilemainclass {

	

	// Main method to execute the program
    public static void main(String[] args) {
        new JTextFileclass();
    }

}
