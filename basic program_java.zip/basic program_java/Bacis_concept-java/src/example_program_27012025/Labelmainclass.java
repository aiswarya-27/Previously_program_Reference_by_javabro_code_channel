package example_program_27012025;

import java.awt.Color;
import java.awt.Image;
import java.awt.Label;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class Labelmainclass {
	
	public static void main(String args[]) {
		
		ImageIcon image= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
		Border border=BorderFactory.createLineBorder(Color.yellow);
		
		JLabel lable = new JLabel();
		lable.setVisible(true);
		lable.setText("i love muruga");
		lable.setHorizontalAlignment(JLabel.CENTER);
	    lable.setOpaque(true); // image back ground color
	    lable.setIcon(image);  // imgae is visible color
	    lable.setBorder(border);  //set of label (not image+text )
		lable.setBounds(235, 170, 135, 120);
		lable.setBackground(Color.green);
	

		
		
		
		JFrame frame = new JFrame();
		frame.setVisible(true);
	
		frame.setBounds(250, 250, 130,150);
		frame.setResizable(true);
		frame.setTitle("This the Label page");
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setIconImage(image.getImage());  // right u can see the image
	frame.add(lable);   //import line 
	}
	}


