package example_program_27012025;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class LayeredPane {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 0, 500, 500);
		
JFrame frame = new JFrame("JLayeredPane"); 
frame.setSize(500, 500);  // Set frame size
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setLayout(null);



JLabel Pane1=new JLabel();
Pane1.setBackground(Color.green);
Pane1.setBounds(50, 50, 100, 100); // Set position & size
Pane1.setOpaque(true);

JLabel Pane2=new JLabel();
Pane2.setBackground(Color.red);
Pane2.setBounds(80, 80, 100, 100); // Shifted slightly
Pane2.setOpaque(true);

JLabel Pane3=new JLabel();
Pane3.setBackground(Color.blue);
Pane3.setBounds(110, 110, 100, 100); // Shifted further
Pane3.setOpaque(true);



// Add panels to the layered pane with different layers
/*
layeredPane.add(Pane1, JLayeredPane.DEFAULT_LAYER);
layeredPane.add(Pane2, JLayeredPane.PALETTE_LAYER);
layeredPane.add(Pane3, JLayeredPane.DRAG_LAYER);
*/

layeredPane.add(Pane1, Integer.valueOf(0));
layeredPane.add(Pane2, Integer.valueOf(1));
layeredPane.add(Pane3, Integer.valueOf(2));


frame.add(layeredPane);
frame.setVisible(true);

	}

}
