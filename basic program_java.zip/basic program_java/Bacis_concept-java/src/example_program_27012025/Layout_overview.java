package example_program_27012025;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.Scanner;

import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


import java.awt.*;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.*;

//public class Layout_overview implements ActionListener {

	//JButton button;
	//JFrame frame;
	
	/*public static void main(String[] args) {
		new Layout_overview();
	}*/
		// TODO Auto-generated method stub
/*
		// Borderlayout
		
		Border order = BorderFactory.createLineBorder(Color.BLUE);
		
		JFrame frame = new JFrame("This my frame details");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 frame.setBounds(300, 300, 300, 300); // Increased size for better visibility
		frame.getContentPane().setBackground(Color.red);
		frame.setLayout(new BorderLayout());
		
		
		JLabel a= new JLabel("Hello, JLabel!", JLabel.CENTER);
		a.setBackground(Color.orange);
		a.setOpaque(true);
		a.setBounds(150, 150, 200, 200);
		// Add label to the center of the frame
        frame.add(a, BorderLayout.CENTER);
        
        JPanel b= new JPanel();
        b.setPreferredSize(new Dimension(45,50));
        b.setBackground(Color.PINK);
       
        
        
        frame.add(b,BorderLayout.BEFORE_FIRST_LINE);
		frame.add(a);
		frame.setVisible(true);
		*/
		
		// Flow layout:(1 method)
		/*
		
		Layout_overview(){
			
		
        frame = new JFrame("This my frame details");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(300, 300, 300, 300); // Increased size for better visibility
		frame.getContentPane().setBackground(Color.red);
		frame.setLayout(new FlowLayout(FlowLayout.LEFT));
		
	    button = new JButton("Click me");
		button.addActionListener(this);
		
		frame.add(button);
		frame.setVisible(true);
		
			@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()== button) {
			button.setEnabled(true);
			System.out.println("this sample buttons");
		}
		
		}
		
	*/
/*
	// flow layout:(2 method)
public class Layout_overview {

	JButton button;
	
	 Layout_overview(){
	JFrame frame = new JFrame("This my frame details");
	
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setBounds(300, 300, 300, 300); // Increased size for better visibility
	frame.getContentPane().setBackground(Color.red);
	frame.setLayout(new FlowLayout(FlowLayout.LEFT));
	
JPanel a=new JPanel();


a.add(new JButton("1"));
a.add(new JButton("2"));


frame.add(a);
frame.setVisible(true);
	 }
public static void main(String[] args) {
	new Layout_overview();
}

	}
*/


/********Girdlayout*********************/
/*********
public class Layout_overview{
	JFrame frame ;
	JButton button;
	
	//constructor
	Layout_overview(){
frame = new JFrame("this my sample Jframe");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setBounds(200, 200, 400, 400);
frame.setLayout(new GridLayout(5,5));// row and column


frame.add(new JButton("1"));
frame.add(new JButton("2"));
frame.add(new JButton("3"));
frame.add(new JButton("4"));
frame.add(new JButton("5"));
frame.add(new JButton("6"));
frame.add(new JButton("7"));
frame.add(new JButton("8"));
frame.add(new JButton("9"));
frame.add(new JButton("10"));

frame.setVisible(true);





	}
public static void main(String[] args) {
	new Layout_overview();
}

}
********************************/

/********JOptionPane ****************/
/********************
public class Layout_overview{
	
	
	public static void main(String[] args) {
		JOptionPane.showInternalConfirmDialog(null, "This my sample message", "Error message", JOptionPane.ERROR_MESSAGE);
		
		JOptionPane.showInternalMessageDialog(null, "this my cancel button","Cancel option",JOptionPane.CANCEL_OPTION);
		JOptionPane.showInternalMessageDialog(null, "this my closed button","Closed option",JOptionPane.CLOSED_OPTION);
		JOptionPane.showInternalMessageDialog(null, "this my Default button","default option",JOptionPane.DEFAULT_OPTION);
		JOptionPane.showInternalMessageDialog(null, "this my cancel button","Cancel option",JOptionPane.CANCEL_OPTION);
		JOptionPane.showInternalMessageDialog(null, "this my error message","Error Message",JOptionPane.ERROR_MESSAGE);
		JOptionPane.showInternalMessageDialog(null, "this my Information mesaage","Information message",JOptionPane.INFORMATION_MESSAGE);
		JOptionPane.showInternalMessageDialog(null, "this my question message","Question Message",JOptionPane.QUESTION_MESSAGE);
		
		ImageIcon icon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
		 JOptionPane.showConfirmDialog(null, "sample page", "i love murugan ",JOptionPane.YES_OPTION,JOptionPane.QUESTION_MESSAGE, 
		            icon);

	}
}
************************/
/*************JOptionpane user input****************/

/*************
public class Layout_overview{
	public static void main(String[] args) {	
Scanner scanner = new Scanner ( System.in);

int age =Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the age"));
//Display the input back to the user
JOptionPane.showInputDialog(null, "your age this ", age);

String name = JOptionPane.showInputDialog(null, "Enter the name");
JOptionPane.showInputDialog(null, "Your name this",name);


	}

}
*************************/

/**************JLayeredPane********************/
/*
public class Layout_overview{
	public static void main(String[] args) {
		
JLayeredPane layeredpane= new JLayeredPane();
layeredpane.setBounds(0, 0, 300, 300); // Set its size

JFrame frame = new  JFrame();
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setBounds(500, 500, 300, 300);
frame.getContentPane().setBackground(Color.PINK);
frame.setLayout(null);

JPanel a= new JPanel();
JPanel a1= new JPanel();
JPanel a2= new JPanel();
// Set bounds for each panel

a.setBounds(50, 50, 100, 100);  // Position (50,50) and size (100x100)
a1.setBounds(70, 70, 100, 100); // Overlapping a bit
a2.setBounds(90, 90, 100, 100); // Overlapping more

a.setBackground(Color.BLACK);
a1.setBackground(Color.GREEN);
a2.setBackground(Color.ORANGE);

layeredpane.add(a, Integer.valueOf(0));

layeredpane.add(a1, Integer.valueOf(1));


layeredpane.add(a2, Integer.valueOf(2));


frame.add(layeredpane);
frame.setVisible(true);

	}
}
*/

/*******************Textfield **********************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	
	JFrame frame;
	JTextField textfield;
	JButton button;
	
	Layout_overview (){
		frame= new JFrame("This my frame title");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		frame.pack();
		

button = new JButton("click me");
button.addActionListener(this);
button.setBackground(Color.yellow);



textfield = new JTextField();
textfield.setBackground(Color.BLUE);
textfield.setPreferredSize(new Dimension(450,45));
textfield.setCaretColor(Color.GREEN);	
textfield.setText("Password");


frame.add(button);
frame.add(textfield);
frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource()== button) {
			button.setEnabled(false);
			System.out.println("welocme"+textfield.getText());
			
		}
		
	}
	

	
}	
*/
/******check box*****************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	
	JFrame frame;
	JCheckBox checkbox;
	JButton button;
	ImageIcon image;
	ImageIcon image1;
	
	Layout_overview (){
		frame= new JFrame("This my frame title");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		frame.pack();
		
		
		checkbox= new JCheckBox();
		checkbox.setBackground(Color.BLACK);
		checkbox.setPreferredSize(new Dimension(450, 50)); // Adjusted size
		checkbox.setFont(new Font("Consolas",Font.PLAIN,35));
		checkbox.setIcon(image);
		checkbox.setSelectedIcon(image1); // Set checked icon
		checkbox.setText("i am not roboot");
		checkbox.setFocusable(false);
		
		button = new JButton("Click me");
		button.addActionListener(this);
		
		image = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//dump_image.png");
		image1 = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//error_image.png");
		
		
		frame.add(button);
		frame.add(checkbox);
		frame.setVisible(true);
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			System.out.println(checkbox.isSelected());
		}
		
	}
	
	

}
*/

/************* Radio button*****************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
JRadioButton a1button;
JRadioButton a2button;
JRadioButton a3button;
JFrame frame;
ImageIcon a1icon;
ImageIcon a2icon;
ImageIcon a3icon;

Layout_overview (){
	frame= new JFrame("This my frame title");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setLayout(new FlowLayout());
	frame.pack();
	
	
 a1button= new JRadioButton("A1Button");
 a2button= new JRadioButton("A2Button");
 a3button= new JRadioButton("A3Button");	
 
 ButtonGroup buttongroup = new ButtonGroup();
 buttongroup.add(a1button);
 buttongroup.add(a2button);
 buttongroup.add(a3button);

 a1button.addActionListener(this);
 a2button.addActionListener(this);
 a3button.addActionListener(this);
 
 frame.add(a1button);
 frame.add(a2button);
 frame.add(a3button);
 
 a1icon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//dump_image.png");
 a2icon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//error_image.png");
 a3icon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//icons8-pinching-hand-48.png");
		 
 a1button.setIcon(a1icon);
 a2button.setIcon(a2icon);
 a3button.setIcon(a3icon);
 
 
 frame.setVisible(true);
	
}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()== a1button) {
			System.out.println("this my test sample a1 button");
		}
		else if(e.getSource()== a2button){
			System.out.println("this my test sample a2 button");
		}
		else if(e.getSource()== a3button){
			System.out.println("this my test sample a3 button");
		}
	}
}
*/
/************* Combo box ************************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	JFrame frame;
	JComboBox combobox;
	
	Layout_overview (){
		frame= new JFrame("This my frame title");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		frame.pack();
		
		Integer[] num= {1,2,3,4,5};
		combobox = new JComboBox(num);
		combobox.isEditable();
		combobox.addActionListener(this);
		
		combobox.addItem(7);  // add the num
System.out.println(combobox.getItemCount());
		
		frame.add(combobox);
		frame.setVisible(true);
	
}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()== combobox) {
			//System.out.println(combobox.getSelectedItem());
			System.out.println(combobox.getItemCount());
		}
	}
	
}
*/
/*******************Slider*********************/
/*
public class Layout_overview implements ChangeListener{
	
	JFrame frame;
	JPanel panel;
	JLabel label;
	JSlider silder;
	
	Layout_overview(){
		
		frame = new JFrame();
		panel = new JPanel();
		label = new JLabel();
		silder= new JSlider();
		
		silder = new JSlider();
		silder.setBackground(Color.green);
		   // Set initial label text
        label.setFont(new Font("Arial", Font.BOLD, 18));
        label.setText(silder.getValue() + "%");

		silder.setPaintTicks(true);
		silder.setMajorTickSpacing(10);
		
		silder.setPaintTrack(true);
		silder.setMinorTickSpacing(5);
		
	    silder.setPreferredSize(new Dimension(100, 300));
		silder.addChangeListener(this);
		
		silder.setPaintLabels(true);//( 10 ,20 ,30 this missing that i will write)
		
		
        
        silder.setOrientation(SwingConstants.VERTICAL);
        
        
		
		panel.add(silder);
		panel.add(label);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 400);
		//frame.setLayout(null);   //this line not mandatory 
		frame.setVisible(true);
		
		
		
	
		
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		// TODO Auto-generated method stub
		if( e.getSource()==silder) {
			 label.setText(silder.getValue() + "%");

		}
	}
	   public static void main(String[] args) {
	        new Layout_overview();
	    }
	}
*/

/*********Progress Bar*************************/
/*
public class Layout_overview extends Layout_overview1 {
	
	JFrame frame;
	JProgressBar progressbar;
	
	Layout_overview(){
		frame = new JFrame("This my sample frame details");
		progressbar = new JProgressBar();
		progressbar.setBackground(Color.BLACK);
		progressbar.setFont(new Font("Arial", Font.BOLD, 18));
		progressbar.setForeground(Color.ORANGE);
		
		progressbar.setValue(0);
		progressbar.setPreferredSize(new Dimension(300, 30));
		progressbar.setStringPainted(true);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 150);
		frame.setVisible(true);
		frame.add(progressbar);
	
	
		sample1();
	}
	public void sample1() {
        int counter = 0;
        while (counter <= 100) {
            try {
                Thread.sleep(100); // Wait for 100 milliseconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            final int value = counter;
            SwingUtilities.invokeLater(() -> progressbar.setValue(value)); // Update progress bar
            
            counter++; // Increment counter
        }

        // Set the text to "Done" after reaching 100%
        SwingUtilities.invokeLater(() -> progressbar.setString("Done"));
    }
}
*/
/**********Menu bar***********************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	JFrame frame;
	JMenuBar menubar;
	JMenu filemenu;
	JMenu editmenu;
	JMenu helpmenu;
	JMenuItem loaditem ;
	JMenuItem saveitem;
	JMenuItem saveasitem;
	JMenuItem saveallitem;
	JMenuItem restartitem;
	JMenuItem paste;
	JMenuItem findreplace;
	JMenuItem delete;
	JMenuItem findnext;
	ImageIcon LoadIcon;
	ImageIcon saveIcon;
	ImageIcon saveAsIcon;
	ImageIcon saveAllIcon;
	ImageIcon restarticon;
	
	
	
	
	Layout_overview(){
		frame = new JFrame();
		menubar = new JMenuBar();
		
		filemenu =new JMenu("File");
		editmenu = new JMenu("Edit");
		helpmenu= new JMenu("Help");
		
		menubar.add(filemenu);
		menubar.add(editmenu);
		menubar.add(helpmenu);
		
		loaditem = new JMenuItem("Load");
		saveitem = new JMenuItem("Save");
		saveasitem = new JMenuItem("SaveAs");
		saveallitem = new JMenuItem("Save All");
		restartitem = new JMenuItem("Restart");
		
		filemenu.add(loaditem);
		filemenu.add(saveitem);
		filemenu.add(saveasitem);
		filemenu.add(saveallitem);
		filemenu.add(restartitem);
		
		loaditem.addActionListener(this);
		saveitem.addActionListener(this);
		saveasitem.addActionListener(this);
		saveallitem.addActionListener(this);
		restartitem.addActionListener(this);
		
		paste= new JMenuItem("Paste");
		findreplace = new JMenuItem("Find/Replace");
		delete= new JMenuItem("Delete");
		findnext = new JMenuItem("FineNext");
		
		editmenu.add(paste);
		editmenu.add(findreplace);
		editmenu.add(delete);
		editmenu.add(findnext);
		
		paste.addActionListener(this);
		findreplace.addActionListener(this);
		delete.addActionListener(this);
		findnext.addActionListener(this);
		
		 LoadIcon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//dump_image.png");
		 saveIcon = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//error_image.png");
		saveAsIcon = new ImageIcon("");
		saveAllIcon = new ImageIcon("");
		restarticon = new ImageIcon("");
		
		loaditem.setIcon(LoadIcon);
		saveitem.setIcon(saveIcon);
		saveasitem.setIcon(saveAsIcon);
		saveallitem.setIcon(saveAllIcon);
		restartitem.setIcon(restarticon);
		
		
        // **Set the menu bar in the frame**
        frame.setJMenuBar(menubar);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500, 500);
		frame.setLayout(new FlowLayout());
		frame.setVisible(true);
		
}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if( e.getSource()==loaditem) {
			System.out.println("this my loaded the file");
		}
		else if(e.getSource()==saveitem) {
			System.out.println("this my save file");
			
		}
		else if(e.getSource()==saveasitem) {
			System.out.println("this my saveas file");
			
		}
		else if(e.getSource()==saveallitem) {
			System.out.println("this my saveAll file");
			
		}
		else if(e.getSource()==restartitem) {
			System.exit(0);
			
		}
		
		
	}
	}
	*/


/**************************** select a file********************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	JFrame frame;
	JButton button;
	Layout_overview(){
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		//frame.setPack();
		
		
		button = new JButton("select a file");
		button.addActionListener(this);
		
		frame.add(button);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button) {
			JFileChooser filechooser = new JFileChooser();
			
			//System.out.println(filechooser.showOpenDialog(null));   // open the file
			int reponse=filechooser.showSaveDialog(null); 
			if(reponse == JFileChooser.APPROVE_OPTION);
			File file = new File(filechooser.getSelectedFile().getAbsolutePath());// get the path reflected in console output
			System.out.println(file);
			
			
		}
		}
	
}
*/
/************************** color chooser****************/
/*
public class Layout_overview extends Layout_overview1 implements ActionListener{
	JFrame frame;
	JButton button;
	JLabel label;
	
	
	Layout_overview(){
		frame = new JFrame("Color Chooser Example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setLayout(null);
	frame.setSize(420, 420);
	frame.setLayout(new FlowLayout());
		
		button = new JButton("color chooser");
		button.addActionListener(this);
		
		
		label =new JLabel();
		//label =new JLabel("This my lable section part");
		label.setText("This my label details");
		label.setOpaque(true);
		label.setFont(new Font("Consolas", Font.BOLD, 15));
		label.setPreferredSize(new Dimension(300, 100));
		
		frame.add(label);
		frame.add(button);
		frame.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == button) {
			JColorChooser  a= new JColorChooser();
			Color color=(JColorChooser.showDialog(null,"this my sample color choose",Color.GREEN));
			//once u run the code click on the color chooser button means u can see the left the this the tile name this my sample color choose
		label.setBackground(color);
		label.setForeground(color.BLUE); // sentence color 
			
			
		}
	}
	
}
*/
/********************Key Listener*************/
/*
public class Layout_overview extends Layout_overview1 implements KeyListener{
	
	JFrame frame;
	JLabel label;
	ImageIcon a;
	Layout_overview(){
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		//frame.addKeyListener(this);
		
		label = new JLabel();
	    label.setBackground(Color.GREEN);
	    label.setBounds(0, 0, 400, 400);
	label.setSize(450,450);
	    
		label.setOpaque(true);
		
		a= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
		label.setIcon(a);
		
		frame.addKeyListener(this);
		frame.add(label);
		
		frame.setVisible(true);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		//keychar
		switch(e.getKeyChar()){
		case 'a':label.setLocation(label.getX()-10, label.getY());
		break;
		case 'i':label.setLocation(label.getX(), label.getY()-10);
		break;
		case 's':label.setLocation(label.getX()+10, label.getY());
		break;
		case 'w':label.setLocation(label.getX(), label.getY()+10);
		break;
		
		
		}
		
		
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		//keycode
		
		switch(e.getKeyCode()){
		case 65:label.setLocation(label.getX()-10, label.getY());
		break;
		case 73:label.setLocation(label.getX(), label.getY()-10);
		break;
		case 83:label.setLocation(label.getX()+10, label.getY());
		break;
		case 87:label.setLocation(label.getX(), label.getY()+10);
		break;
		
		
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("This my key Listener char : "+e.getKeyChar());
		System.out.println("This my key Listener code : "+e.getKeyCode());
	}
}

*/
/************ Mouse Listener(method 1)*************************/
/*
public class Layout_overview extends Layout_overview1 implements MouseListener{
JFrame frame;
JLabel label;

	Layout_overview(){
		frame= new JFrame("this my mouse listener");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		//frame.setSize(500,500);
		
		label = new JLabel();
		label.setText("this sample of label in mouse listener");
		label.setOpaque(true);
        label.setBounds(0, 0, 100, 100);
        label.setBackground(Color.ORANGE);
        label.setForeground(Color.red);  // sentence color
        
        
        frame.add(label);
        frame.addMouseListener(this);
        frame.setVisible(true);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("this my mouseclicked process");
		label.setBackground(Color.BLUE);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("this my mousePressed process");
		label.setBackground(Color.YELLOW);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("this my mouseReleased ");
		label.setBackground(Color.black);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("this my mouseEntered component ");
		label.setBackground(Color.GREEN);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("this my mouseExited component ");
		label.setBackground(Color.PINK);
	}
}
*/

/*****      MouseListener method-2 *****************************/
/*
public class Layout_overview extends Layout_overview1 implements MouseListener{
	
	JFrame frame;
	JLabel label;
	ImageIcon a;
	ImageIcon b;
	ImageIcon c;
	ImageIcon d;
	ImageIcon e;
	
	Layout_overview(){
		frame= new JFrame("this my mouse listener");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new FlowLayout());
		//frame.setSize(500,500);
		
		label = new JLabel();
		//label.setText("this sample of label in mouse listener");
		label.setOpaque(true);
        label.setBounds(0, 0, 100, 100);"C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//shivam.png"
        label.setBackground(Color.ORANGE);
        
        a= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//dump_image.png");
        b= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//error_image.png");
        c= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//icons8-pinching-hand-48.png");
        d= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
        e= new ImageIcon();
        
        
       label.setIcon(e);
        
        frame.add(label);
        frame.addMouseListener(this);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		label.setIcon(a);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		label.setIcon(b);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		label.setIcon(c);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		label.setIcon(d);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		//label.setIcon(e);
	}
}
*/

/*********************Drag and drop****************/
/*
public class Layout_overview extends Layout_overview1{
	
	JFrame frame= new JFrame("This sample page in drag and drop");
	  Layout_overview_panel panel;
	  
	Layout_overview(){
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0, 400, 400);
		frame.setLayout(null);
		
		panel = new Layout_overview_panel();
        frame.add(panel); // Add the panel with image
		frame.setVisible(true);
		
		
	}

}
*/

/***********************Key Bindings*****************/
/*
public class Layout_overview extends Layout_overview1{
	
	JFrame frame;
	JLabel label;
	Action upAction;
	Action downAction;
	Action rightAction;
	Action leftAction;
	Layout_overview(){
		
		frame = new JFrame("This my sample page of JFrame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBackground(Color.PINK);
		frame.setBounds(400, 400, 400, 400);
		frame.setLayout(null);
		
		label = new JLabel();
		label.setBounds(100, 100, 100, 100);
		label.setBackground(Color.green);
		label.setOpaque(true);
		
		 // Create action objects
        upAction = new UpAction();
        downAction = new DownAction();
        rightAction = new RightAction();
        leftAction = new LeftAction();
        
		
		label.getInputMap().put(KeyStroke.getKeyStroke('A'),upAction);
		label.getActionMap().put(upAction, upAction);
		
		label.getInputMap().put(KeyStroke.getKeyStroke('i'),downAction);
		label.getActionMap().put(downAction, downAction);
		
		label.getInputMap().put(KeyStroke.getKeyStroke('s'),rightAction);
		label.getActionMap().put(rightAction, rightAction);
		
		label.getInputMap().put(KeyStroke.getKeyStroke('w'),leftAction);
		label.getActionMap().put(leftAction, leftAction);
		
		frame.add(label);
		frame.setVisible(true);
		
	}
	public class UpAction extends AbstractAction{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			//label.setLocation(label.getX()+10, label.getY());
			label.setLocation(label.getX(), label.getY() - 10);
			
			
		}
	}
		public class DownAction extends AbstractAction{

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//label.setLocation(label.getX(), label.getY()+10);
				label.setLocation(label.getX(), label.getY() + 10); // Move Down
			}
		}
			public class RightAction extends AbstractAction{

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					//label.setLocation(label.getX()-10, label.getY());
					 label.setLocation(label.getX() + 10, label.getY()); // Move Right
				}
			}
				public class LeftAction extends AbstractAction{

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						//label.setLocation(label.getX(), label.getY()-10);
						label.setLocation(label.getX() - 10, label.getY()); // Move Left
					}	
	}
		
			
}
*/

/************* 2D graphics*************************/
/*
public class Layout_overview extends Layout_overview1{
	
	JFrame frame;
	Layout_overview_panel panel;
	
	 Layout_overview(){
		 frame = new JFrame("this my 2d graphics");
		 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 frame.setBounds(0, 0, 100, 100);
		 frame.pack();
		 frame.setLocationRelativeTo(null);
		 
		 
		 panel = new Layout_overview_panel();
		 frame.add(panel);
		
		 frame.setVisible(true);
		 
		 
		 
	 }
}
*/
/******************* 2D animation**************/
/*
public class Layout_overview extends Layout_overview1{
	JFrame frame;
	Layout_overview_panel panel;
	
	Layout_overview(){
		 frame = new JFrame("this my 2d animation");
		 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 frame.setBounds(0, 0, 100, 100);
		 frame.pack();
		 frame.setLocationRelativeTo(null);
		 
		 panel = new Layout_overview_panel();
		 frame.add(panel);
		
		 frame.setVisible(true);
}
}
*/

