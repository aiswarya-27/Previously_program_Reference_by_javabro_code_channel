package example_program_27012025;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//class Layout_overview_panel extends JPanel {
	
	/*
	JFrame frame;
    ImageIcon image= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//shivam.png");
    //image = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//shivam.png");
    final int width = image.getIconWidth();
    final int height = image.getIconHeight();
    Point imageCorner;
    Point prevPt;

    Layout_overview_panel() {
        
        imageCorner = new Point(500, 500); // Initial position of the image

        ClickListener clickListener = new ClickListener();
        DragListener dragListener = new DragListener();
        
        this.addMouseListener(clickListener);
        this.addMouseMotionListener(dragListener);
        
        frame = new JFrame();
       
        frame.setIconImage(image.getImage());
        frame.add(this);
        frame.setVisible(true);
    }
	public void paintComponent(Graphics g) {
		
		 super.paintComponent(g);
	     image.paintIcon(this, g, (int) imageCorner.getX(), (int) imageCorner.getY()); // FIX: Use `this` instead of `frame`
	}
	
	private class ClickListener extends MouseAdapter{
		public void mousePressed (MouseEvent e) {
			prevPt =e.getPoint();
		}
	}
	
	private class DragListener extends MouseMotionAdapter{
		public void mouseDragged (MouseEvent e) {
			Point currentPt = e.getPoint();
			imageCorner.translate(
					(int) ( currentPt.getX()-prevPt.getY()),
					(int) ( currentPt.getX()-prevPt.getY())
					);
			prevPt=currentPt;
			Layout_overview_panel.this.repaint();
			
		}

		
	}
		*/
	
	
	// 2d graphics 
/*
class Layout_overview_panel extends JPanel {
	Image i;
	
	Layout_overview_panel(){
		this.setPreferredSize(new Dimension(500,500));
		
		
	}
	public void paintComponent(Graphics g) {
		//protected void paintComponent(Graphics g){
		 super.paintComponent(g); // Call the superclass method to ensure proper rendering
	        Graphics2D g2D = (Graphics2D) g;
	        
	        i= new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png").getImage();
			g2D.drawImage(i,0,0,null);
	        
	        //g2D.setPaint(Color.BLACK);
	        //g2D.drawOval(0, 0, 100, 100);  // oval symbol
	        //g2D.fillOval(0, 0, 100, 100);   // inside oval symbol color we have put
	        
	       g2D.setPaint(Color.RED);
	        g2D.setPaint(Color.magenta);
	        g2D.drawArc(0,0,100,100,0,180);
	        g2D.fillArc(0,0,100,100,0,180);
	        
	        
	        
	        g2D.setPaint(Color.GREEN);
	        g2D.fillArc(0,0,100,100,0,180);
	        
	        
	        //g2D.setPaint(Color.BLUE);
	        //g2D.fillArc(0,0,100,100,0,180);   //(FRAMEBITS, ERROR, WIDTH, HEIGHT, ALLBITS, ABORT);
	      
	        
	        
	        int [] xPoints = {150,250,350};
	        int [] yPoints = {300,150,300};
	        
	        g2D.setPaint(Color.yellow);
	        g2D.drawPolygon(xPoints, yPoints, 3);
	        g2D.fillPolygon(xPoints, yPoints, 3);
	        
	        
	        g2D.setPaint(Color.RED);// sentences clor red 
	        g2D.setFont(new  Font("INK Free",Font.BOLD,50));  // sentences font 
	        g2D.drawString("muruga is my always",50,50); 
	        //(TOOL_TIP_TEXT_KEY, ALLBITS, ABORT);
	        
		}
		
		  
		
	}	
	*/

/********************2d animation******************/
/*
class Layout_overview_panel extends JPanel implements ActionListener {
	final int panel_width = 50;
    final int panel_height = 50;
    Image i;
    Image backgroundImage;
    Timer timer;
    int xVelocity = 2;
    int yVelocity = 2;
    int x = 0;
    int y = 0;
    Layout_overview_panel(){
    	this.setPreferredSize(new Dimension(panel_width, panel_height ));
    	i = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Screenshot 2025-03-04 153252.png")
    			.getImage();
       // backgroundImage = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Screenshot 2025-03-04 153328.png").getImage();
    	this.setBackground(Color.BLACK);
        timer = new Timer(100,this);
        timer.start();
        
    	
    }
    public void paint(Graphics g) {
    	super.paintComponent(g);
    	Graphics2D g2D =(Graphics2D)g;
    	g2D.drawImage(backgroundImage,x,y,null);
    	g2D.drawImage(i,x,y,null);
    	
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		if(x>panel_width-i.getWidth(null)){
			 xVelocity = xVelocity*-1;
		}
		if(x<panel_height-i.getHeight(null)) {
			xVelocity = xVelocity*-1;
		}
		x += xVelocity;
        y += yVelocity;
		repaint();
		
		//Bouncing Logic
		/*
        if (x >= panel_width - i.getWidth(null) || x < 0) {
            xVelocity = -xVelocity;
        }
        if (y >= panel_height - i.getHeight(null) || y < 0) {
            yVelocity = -yVelocity;
        }
        
        x += xVelocity;
        y += yVelocity;
        
        repaint();
        */
	//}
	
//}






	
	        
	      
	        


	

