package example_program_27012025;

public class Methodoverriding2 extends Methodoverriding{
	@Override
	void process() {
		System.out.println("This my process");
	}
	void test() {
		System.out.println("this my test");
	}
}
