package example_program_27012025;

public class Methodoverridingmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Methodoverriding a=new Methodoverriding();

a.test();
a.process();


	}

}
