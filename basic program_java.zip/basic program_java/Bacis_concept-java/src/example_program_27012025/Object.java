package example_program_27012025;

public class Object {
	// attritues declation
	int age =90;
	String name ="Muruga";
	double d=90.34;
	float f=78.90f;
	char c='#';
	boolean b=true;
	
	//we needed to created method 
	
	void add() {
		System.out.println("This my age details: "+age);
	}
	
	void add1() {
		System.out.println("This my name details: "+name);
	}
	
	void add2() {
		System.out.println("This my double details: "+d);
	}
	void add3() {
		System.out.println("This my float details: "+f);
	}
	
	void add4() {
		System.out.println("This my char details: "+c);
	}
	void add5() {
		System.out.println("This my age details: "+b);
	}

}
