package example_program_27012025;

public class ObjectMainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object a= new Object();
		
		Object a1= new Object();
		
		System.out.println(a.age);
		System.out.println(a.b);
		System.out.println(a.c);
		System.out.println(a.d);
		System.out.println(a.f);
		System.out.println(a.name);
		
		System.out.println(" ");
		
		a1.add();
		a1.add1();
		a1.add2();
		a1.add3();
		a1.add4();
		a1.add5();
	}

}
