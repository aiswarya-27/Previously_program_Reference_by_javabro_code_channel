package example_program_27012025;

public class ObjectPassing1 {
	
	void ObjectPassing111(ObjectPassing2 a1){
		System.out.println("this my objectpassing2:"+a1.age+"\n"+a1.d+"\n"+a1.c);
	}
	
	void ObjectPassing123(ObjectPassing3 a2){
		System.out.println("This my ObjectPassing3:"+a2.dasid+"\n"+a2.empid);
	}

	

}
