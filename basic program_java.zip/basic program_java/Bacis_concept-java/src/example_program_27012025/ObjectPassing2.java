package example_program_27012025;

public class ObjectPassing2 {
	
	int age;
	double d;
	char c;
	
	ObjectPassing2(int age,double d,char c){
		this.age=age;
		this.d=d;
		this.c=c;
		
	}

}
