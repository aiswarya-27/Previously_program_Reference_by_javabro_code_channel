package example_program_27012025;

public class ObjectPassing3 {

	String dasid;
	String empid;
	
	ObjectPassing3(String dasid,String empid){
		this.dasid=dasid;
		this.empid=empid;
		
	}
}
