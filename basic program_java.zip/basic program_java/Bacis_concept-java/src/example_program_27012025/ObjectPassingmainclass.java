package example_program_27012025;

public class ObjectPassingmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ObjectPassing1 obj = new ObjectPassing1();
		 ObjectPassing2 obj2 = new ObjectPassing2(23, 23.4, 'r');
	     ObjectPassing3 obj3 = new ObjectPassing3("A868685", "123356@");

	        // Passing objects to methods
	        obj.ObjectPassing111(obj2);
	        obj.ObjectPassing123(obj3);

	}

}
