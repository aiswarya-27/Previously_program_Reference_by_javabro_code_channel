package example_program_27012025;

public class OverloadedConstructor {

	String name;
	int age;
	double d;
	char c;
	

	 OverloadedConstructor(String name){
		this.name= name;
	}
	 OverloadedConstructor(String name,int age){
		this.name= name;
		this.age=age;
	}
 OverloadedConstructor(String name,int age,double d){
		this.name= name;
		this.age=age;
		this.d=d;
	}
	OverloadedConstructor(String name,int age,double d,char c){
		this.name= name;
		this.age=age;
		this.d=d;
		this.c=c;
	}
}


