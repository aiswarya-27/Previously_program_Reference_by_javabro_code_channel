package example_program_27012025;

public class OverloadedConstructormainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverloadedConstructor a= new OverloadedConstructor("Aishu",78,98.7,'&');
	
		System.out.println(a.age);
		System.out.println(a.c);
		System.out.println(a.d);
		System.out.println(a.name);
	}

}
