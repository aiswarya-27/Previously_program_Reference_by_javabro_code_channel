package example_program_27012025;

public class Overloadedmethodmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int age = 89;
	        int num = 90;
	        int age1 = 96;
	        int num1 = 56;

	        // Calling all overloaded methods one by one
	        System.out.println("Returned Value: " + add(age));                 // Calls method with 1 parameter
	        System.out.println("Returned Value: " + add(age, num));            // Calls method with 2 parameters
	        System.out.println("Returned Value: " + add(age, num, age1));      // Calls method with 3 parameters
	        System.out.println("Returned Value: " + add(age, num, age1, num1));// Calls method with 4 parameters
	        
	        String strage="A868582";
	        String strnum="A@3456";
	        String strage1="A87jjh";
	        String strnum1="gduvadbwqjkhd";
	        
	     // Calling all overloaded methods one by one
	        System.out.println("Returned Value: " + names(strage));                 // Calls method with 1 parameter
	        System.out.println("Returned Value: " + names(strage, strnum));            // Calls method with 2 parameters
	        System.out.println("Returned Value: " + names(strage, strnum,strage1));      // Calls method with 3 parameters
	        System.out.println("Returned Value: " + names(strage,strnum,strage1,strnum1));// Calls method with 4 parameters		
	        	
	}

	static int add(int age) {
		System.out.println("This my Primtive data type 1:"+age);
		return age;
	}
	static int add(int age,int num) {
		System.out.println("This my Primtive data type 2:"+age+" "+num);
		return age+num;
	}
	static int add(int age,int num,int age1) {
		System.out.println("This my Primtive data type 3:"+age+" "+num+" "+age1);
		return age+num+age1;
				}
	static int add(int age,int num,int age1,int num1) {
		System.out.println("This my Primtive data type 4:"+age+" "+num+" "+age1+" "+num1);
		return age+num+age1+num1;
	}
	
	static String names(String age) {
		System.out.println(" this my Reference data types 5 :"+age);
		return age;
	}
	
	static String names(String age,String num) {
		System.out.println(" this my Reference data types 6 :"+age+" "+num);
		return age+num;
	}
	static String names(String age,String num, String age1) {
		System.out.println(" this my Reference data types 7 :"+age+" "+num+" "+age1);
		return age+num+age1;
	}
	static String names(String age,String num, String age1,String num1) {
		System.out.println(" this my Reference data types 8 :"+age+" "+num+" "+age1+" "+num1);
		return age+num+age1+num1;
	}
}


