package example_program_27012025;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Panelmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ImageIcon image = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//Murugan_11022025.png");
		ImageIcon image1 = new ImageIcon("C://BGV_BackEnd//Bacis_concept-java//src//example_program_27012025//icons8-pinching-hand-48.png");
		//Border border=BorderFactory.createCompoundBorder();
		Border border=BorderFactory.createLineBorder(Color.yellow);
	
		// Create Panels
        JPanel redPanel = new JPanel();
        redPanel.setLayout(null); 
        redPanel.setBackground(Color.RED);
        redPanel.setBounds(50, 50, 200, 200);

        JPanel greenPanel = new JPanel();
        greenPanel.setBackground(Color.GREEN);
        greenPanel.setBounds(270, 50, 200, 200);

        JPanel orangePanel = new JPanel();
        orangePanel.setBackground(Color.ORANGE);
        orangePanel.setBounds(50, 270, 200, 200);
		
		JLabel label = new JLabel();
		label.setBackground(Color.CYAN);
		label.setBounds(10, 10, 80, 30);
		label.setOpaque(true);
		//label.setForeground(Color.BLACK);
		label.setIcon(image1);
		label.setBorder(border);
		
		//redPanel.add(label);
		//greenPanel.add(label);
		
		
		JLabel label1 = new JLabel();
		label1.setBackground(Color.black);
		label1.setBounds(70, 50, 200, 200);
		label1.setOpaque(true);
		//label.setForeground(Color.BLACK);
		label1.setIcon(image);
		
		label1.setBorder(border);
		
		
		
		JFrame frame = new JFrame();
		frame.setSize(500, 500);
		frame.setTitle("i love god muruga");
		frame.setVisible(true);  // Set visibility after all components are added
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setLayout(null);  // Disable layout manager
		 frame.getContentPane().setBackground(Color.BLUE);
		 frame.setIconImage(image.getImage()); // right u can see the image
		
		// Add panels to frame
	frame.add(redPanel);
	frame.add(greenPanel);
	frame.add(orangePanel);
	frame.add(label);
	frame.add(label1);
	
	greenPanel.add(label1);
	
	
	

	}

}
