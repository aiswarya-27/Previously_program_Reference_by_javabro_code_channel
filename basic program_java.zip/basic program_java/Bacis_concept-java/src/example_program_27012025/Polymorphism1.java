package example_program_27012025;

public class Polymorphism1 {

	String name;
	
	Polymorphism1(String name){
		this.name=name;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
}
