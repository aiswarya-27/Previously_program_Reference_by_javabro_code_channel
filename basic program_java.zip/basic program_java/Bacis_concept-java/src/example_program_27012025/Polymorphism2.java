package example_program_27012025;

public class Polymorphism2 extends Polymorphism1{

	Polymorphism2(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
