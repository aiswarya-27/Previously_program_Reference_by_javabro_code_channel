package example_program_27012025;

public class Polymorphism3 extends Polymorphism1{

	Polymorphism3(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
