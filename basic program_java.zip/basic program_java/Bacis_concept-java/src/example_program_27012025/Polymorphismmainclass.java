package example_program_27012025;

public class Polymorphismmainclass {

	public static void main(String[] args) {
		   // Creating objects
        Polymorphism2 p1 = new Polymorphism2("aishu");
        Polymorphism3 p2 = new Polymorphism3("aishusai");
        
        // Array of Polymorphism1 type (assuming Polymorphism2 and Polymorphism3 extend Polymorphism1)
        Polymorphism1[] p = {p1, p2};

        // Corrected for loop
        for (Polymorphism1 x : p) {
            System.out.println(x.getName()); // Assuming getName() method exists
        }
	
	}

}
