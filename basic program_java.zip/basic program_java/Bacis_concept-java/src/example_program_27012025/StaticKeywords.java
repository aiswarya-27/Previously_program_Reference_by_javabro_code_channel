package example_program_27012025;

public class StaticKeywords {
String name;
int age;
double d;
static int processtext;
	
	StaticKeywords(String name,int age,double d){
		this.name=name;
		this.age=age;
		this.d=d;
		processtext++;
	}

}
