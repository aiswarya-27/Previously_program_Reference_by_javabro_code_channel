package example_program_27012025;

public class StaticKeywordsmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StaticKeywords s=new StaticKeywords("Aishu",78,67.3);
		StaticKeywords s1=new StaticKeywords("Aishusai",56,34.3);
		StaticKeywords s2=new StaticKeywords("Pramilaishu",89,3.3);
		
		System.out.println(StaticKeywords.processtext);
		System.out.println(s.name);
		System.out.println(s1.name);
		System.out.println(s2.name);
		
		
		System.out.println(s.age);
		System.out.println(s1.age);
		System.out.println(s2.age);
		
		System.out.println(s.d);
		System.out.println(s1.d);
		System.out.println(s2.d);
	}

}
