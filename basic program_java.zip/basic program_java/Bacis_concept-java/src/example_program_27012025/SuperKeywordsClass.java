package example_program_27012025;

public class SuperKeywordsClass {

	String name;
	int age;
	boolean b;
	
	SuperKeywordsClass(String name,int age,boolean b){
		this.name=name;
		this.age=age;
		this.b=b;
	}
	
	public String toString() {
		return name+"\n"+age+"\n"+b;
	}
}
