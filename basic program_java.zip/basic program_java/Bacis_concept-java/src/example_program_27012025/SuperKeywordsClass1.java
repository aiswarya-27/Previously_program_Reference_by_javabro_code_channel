package example_program_27012025;

public class SuperKeywordsClass1 extends SuperKeywordsClass {

	String dasid;
	
	// Auto-generated constructor stub
	SuperKeywordsClass1(String name, int age, boolean b,String dasid) {
		super(name, age, b);
		this.dasid=dasid;
		
	}
	
	public String toString() {
return super.toString()+this.dasid+"this my SuperKeywordsClass1 value";
}
}
