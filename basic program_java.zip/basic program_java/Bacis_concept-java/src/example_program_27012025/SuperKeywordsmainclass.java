package example_program_27012025;

public class SuperKeywordsmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperKeywordsClass1 s= new SuperKeywordsClass1("Aishu", 25, false, "A8686852");
		SuperKeywordsClass1 s1= new SuperKeywordsClass1("Aishusai", 24, true, "75089591");
		
		System.out.println(s.name+" "+s.age+" "+s.b+" "+s.dasid);
		
		System.out.print(s1.name+" "+s1.age+" "+s1.b+" "+s1.dasid);
	}

}
