package example_program_27012025;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
/*
public class TimerTaskmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timer a= new Timer();
		
		TimerTask b= new TimerTask() {

			// add unimplemnted this below line in 16  to 20
			@Override
			public void run() {
				// TODO Auto-generated method stub
				System.out.println("This sample messsage :");
			}
			
		};
		// 19 line print in console msg itself
		a.schedule(b, 3000);  // b is timerbask is variable name :b     ; time : 0 sec
	}

}
*/

/*
public class TimerTaskmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timer a= new Timer();
		
		TimerTask b= new TimerTask() {

			int counter = 10;
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(counter>0) {
				System.out.println(counter+" new sec");
				counter--;
			}
				else {
					System.out.println("This my Sample TimerTask Message");
				}
			}
		};
		
		
	Calendar date =Calendar.getInstance();
	//date.set(Calendar.DATE,07);
	date.set(Calendar.DAY_OF_MONTH,Calendar.MARCH);
	date.set(Calendar.DAY_OF_YEAR,2025);
	date.set(Calendar.HOUR_OF_DAY, 0);
	date.set(Calendar.SECOND, 0);
	date.set(Calendar.MINUTE, 0);
	date.set(Calendar.DAY_OF_MONTH,20);
	date.set(Calendar.MILLISECOND,0);
	
	
		//a.schedule(b, 3000);  // b is timerbask is variable name :b     ; time : 0 sec
	
	a.schedule(b,date.getTime());
	a.scheduleAtFixedRate(b, 0, 1000);
	a.scheduleAtFixedRate(b, 0, 1000);
	}
}
*/
/*
public class TimerTaskmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timer a= new Timer();
		
		TimerTask b= new TimerTask() {

              int counter = 10;
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(counter>0) {
				System.out.println(counter+"seconds");
				counter--;
			}
				else {
					System.out.println("happy women's day");
				}
			}
		};
		Calendar date =Calendar.getInstance();
		//date.set(Calendar.DATE,07);
		date.set(Calendar.MONTH,Calendar.MARCH);
		date.set(Calendar.DAY_OF_YEAR,2025);
		date.set(Calendar.HOUR_OF_DAY, 0);
		date.set(Calendar.SECOND, 0);
		date.set(Calendar.MINUTE,0);
		date.set(Calendar.DAY_OF_MONTH,8);
		date.set(Calendar.MILLISECOND,0);
		
		
			//a.schedule(b, 3000);  // b is timerbask is variable name :b     ; time : 0 sec
		
		//a.schedule(b,date.getTime());
		a.scheduleAtFixedRate(b, 0, 1000);
		//a.scheduleAtFixedRate(b, 0, 1000);
	}

}
*/

public class TimerTaskmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timer a= new Timer();
		
		TimerTask b= new TimerTask() {

              int counter = 10;
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if(counter>0) {
				System.out.println(counter+"seconds");
				counter--;
			}
				else {
					System.out.println("happy women's day");
				}
			}
		};
		Calendar date =Calendar.getInstance();
		//date.set(Calendar.DATE,07);
		date.set(Calendar.MONTH,Calendar.MARCH);
		date.set(Calendar.DAY_OF_YEAR,2025);
		date.set(Calendar.HOUR_OF_DAY, 0);
		date.set(Calendar.SECOND, 0);
		date.set(Calendar.MINUTE,0);
		date.set(Calendar.DAY_OF_MONTH,8);
		date.set(Calendar.MILLISECOND,0);
		
		
			//a.schedule(b, 3000);  // b is timerbask is variable name :b     ; time : 0 sec
		
		//a.schedule(b,date.getTime());
		//a.scheduleAtFixedRate(b, 0, 1000);
		a.scheduleAtFixedRate(b, date.getTime(), 1000);
	}

}

