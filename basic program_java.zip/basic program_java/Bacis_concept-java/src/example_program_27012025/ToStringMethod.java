package example_program_27012025;

public class ToStringMethod {

	String name;
	ToStringMethod(String name){
		this.name=name;
	}
	public String toString() {
		
		return name;
	}
}
