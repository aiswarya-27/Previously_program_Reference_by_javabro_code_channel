package example_program_27012025;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/* high level language is human
		 * low level lanaguage is system,laptop
		 * source code is written by human( the file save like : .file extension)
		 * source code and byte ( compiler translate complier process)
		 * byte code writen ( the file shoule be save like this: .class extension)( this is cross platfrom)
		 * byte code and machine code(translate run process)
		 * object and machine code ( 0101010101)
		 */
		
		/*
		 * JVM --> java virual machine  ---> run java program
		 * JRE----> java run time environment   ---> library and tool
		 * JDK ----> java Development kit   ---> deveolper tool
		 */
		
		
		/**********************Variable***************************************/
		/*
		int a= 89;  // intializing
		
		double d=90.89;
		String name="ais";
		char Char='@';
		boolean b=true;
		
		System.out.println(a+" "+d+" "+name+" "+Char+" "+b);
		*/
		
		
		/*********************Expression Program**************/
		/*
		int a=90;
		a=a/9;
		
		double d=89.7;
	//ouble d1 =d+6;
d=89.7*6;
		float f= 678.0f;
		f--;
		
		boolean b=true;
		
		System .out.println(a);
		
		System .out.println(d);
	
		
		System .out.println(f);
		
		System.out.println(b);
		*/
		
		/***************** Swap variable***************/
		/*int a=90;
		double d =89.7;
		float f=89.70f;
		int temp;
		
		temp =a;
	//a= d;
	d=f;
	f =temp;
		
		System.out.println(temp);
		System .out.println(a);
		System .out.println(d);
		System .out.println(f);
		*/
		
		/*****************GUI*******************/
		/*
		String name= JOptionPane.showInputDialog("Enter the your name");
		JOptionPane.showMessageDialog(null,"Hii"+name );
		
		int age=Integer.parseInt(JOptionPane.showInputDialog("enter the your age"));
		JOptionPane.showMessageDialog(null, "your age this "+age);
		
		double d=Double.parseDouble(JOptionPane.showInputDialog("enter the double value here"));
		JOptionPane.showMessageDialog(null,"your double value this"+d);
		*/
		
		/*******************User input *********************/
		/*
	Scanner scanner =  new Scanner ( System.in);
	
	System.out.println("Pls enter below details here");
	
	System.out.println("Enter the interger type here");
	int choice = scanner.nextInt();
	

	System.out.println("Enter your name here");
	String name=scanner.next();
	

	System.out.println("Enter your 2^nd name here");
	String name1 =scanner.next();
	*/
		
		/************* if statement*****************************/
		/*
		int a=8978;
	if(a==90) {
		System.out.println("This not same value");
	}
		else if(a>=100) {
			System.out.println("This not the greater the value of a");
		}
			else if(a<=70) {
				System.out.println("this my correct the value of a");
			}
			else {
				System.out.println("it is not valid the data");
		}
		*/
		/*********** logical Operators*****************************/
		/*
		Scanner scanner = new Scanner(System.in);

        System.out.println("Kindly print the Integer type here:");
        int choice = scanner.nextInt();
        
        // Consume the leftover newline after reading an integer
        scanner.nextLine(); // This will consume the newline character

        if (choice == 89) {
            System.out.print("This is my choice correct value.");
        } else {
            System.out.print("This is not valid data.");
        }
        
        System.out.println("");
        
/***************AND Operators *************************/
        // Now proceed with the string inputs
        /*
        System.out.println("Kindly enter reference type here: AND Operator");
        String name = scanner.nextLine();
        
        String name1 = scanner.nextLine();
        // both condition true means the output true another way it is false
        if (name.equals("Aishu") && name1.equals("AISHU")) {
            System.out.print("You're still printing the correct data.");
        }  else {
            System.out.print("This is invalid data.");
        }

 
        System.out.println("");
        */
        
        /***************** OR operators*************************/
        // Now proceed with the string inputs
       /*
        System.out.println("Kindly enter reference type here : OR Operator");
        String name2= scanner.nextLine();
        
        String name3= scanner.nextLine();
        //either one condition the output true
      if (name2.equals("Aishusai") || name3.equals("AISHUSAI")) {
    		  
            System.out.print("You're still printing the correct data.");
        } 
        else {
            System.out.print("This is invalid data.");
        }

      
        System.out.println("");
        */
        
        /************NOT Operator************************/
        /*
        System.out.println("Kindly enter The Interger Type here");
        int age = scanner.nextInt();
        
        if(!(age<=80) && !(age<=67)){
        	System.out.print("this my Not operators function");
        }else {
        	System.out.print("In valid Not operator function");
        	
        }
        scanner.close();
        */
		
	/************ Switch Statment******************/
		/*
		Scanner scanner = new Scanner ( System.in);
		System.out.println("Enter the interger types here");
		
		int sample=scanner.nextInt();
		
		switch(sample) {
		case 1: System.out.println("this 1 st value");
		break;
		case 2: System.out.println("this 2 nd value");
		break;
		case 3: System.out.println("this 3 rd value");
		break;
		default:
			System.out.println("In vaild data");
		}
		
		 // Consume the newline character left by nextInt()
        scanner.nextLine();
        
		System.out.println("Kindly enter Reference type here");
		String name=scanner.nextLine();
		
		switch(name) {
		case "Aishu":System.out.println("this 1 st value of name");
		break;
		case "Pramila":System.out.println("this 2 nd value of name");
		break;
		case "Ramesh":System.out.println("this 3 rd value of name");
		break;
		case "Murugan":System.out.println("this 4th value of name");
		break;
		case "Kousalya":System.out.println("this 5th value of name");
		break;
		default:
			System.out.println("Invalid data of names");
		}
		// Close the scanner to avoid resource leaks
        scanner.close();
        */
		
		/*************While loop***********************/
		/*
		Scanner scanner = new Scanner(System.in);
		System.out.println("this is the while and dowhile condition ");
		String name="";
		
		do {
			System.out.println("pls enter the name");
		 name=scanner.nextLine();
		}while(name.isBlank());
		System.out.println("hello"+name);
		 scanner.close();
		 */
		
		/****************for loop statement*****************/
		/*
		for (int i=1; i<=10;i++) {
			System.out.println(i);
		}
		System.out.println("");
		// Loop from 10 to 1
        for (int j = 10; j >= 1; j--) {
            System.out.println(j);
        }
        */
	
        
        /*********************Nested for loop statement************/
		/*
		Scanner scanner = new Scanner( System.in);
		System.out.println("Enter the Nested for loop statement");
		
		System.out.println("This my Interger data type of a value");
		int a =scanner.nextInt();

		System.out.println("this my Interger data type of b value");
		int b=scanner.nextInt();
	
		 // Consume the newline character left by nextInt()
        scanner.nextLine();
        
		System.out.println("this Reference type of the c value");
		String c=scanner.nextLine();
	
		System.out.println("This double value of the d");
		double d=scanner.nextDouble();
		
		 // First nested loop using 'a'
        System.out.println("Output of first nested loop:");
		for(int i=1; i<=a ; i++) {
			System.out.println(c);
		}
		
		// Second nested loop using 'b'
        System.out.println("Output of second nested loop:");
			for(int j=1;j<=b; j++) {
				System.out.println(d);
			}
		
		scanner.close();
		*/
		
		/*******************Array using for loop statment******************/
		//array: it is contains store mutli value in single variable
		/*
		int a[]= {7,8,56,456,90,5678,756};
		
		 // Accessing the 6th value of the array (index 6)
        System.out.println("This is the 6th value of the array: " + a[6]);
        
        // Updating the 5th value of the array (index 4)
        a[4] = 90789;
        System.out.println("Updated 5th value of the array: " + a[4]);
	
        //System.out.println(a);---> it sould conatin the addresss
        // Corrected loop to iterate through the array
        System.out.println("Array elements:");
		for(int i=0;i<a.length;i++) {
			System.out.println("this ln is needed:"+a[i]);
			//System.out.print("this lin is not needed:"+a[i]);
		}
		
		System.out.println("");
		
		String name[]= {"Aishu","sai","pramila"};
		 System.out.println("The 3rd name in the array: " + name[2]);
		 
		*/
		 
	/******************2D array*****************/
		/*
		  // Declaring a 4-dimensional array
		 int a1[][]= {
				 {1,9,0,78},
				 {7,8,67,79},
				 {56,23,6,14},
				 {90,94,54,24},
				 };
		 // Iterating through the 2D array and printing its elements
	        System.out.println("Array elements:");
		 for(int i=0;i<a1.length;i++) {   // Loop through rows
		for(int j=0;j<a1[i].length;j++) {  // Loop through columns
			System.out.print(a1[i][j]+"");  // Print each element in a row
		}
		
		System.out.println(); // Move to the next line after each row
		 }
		
		 
		 String sample[][]= {
				 {"Aishu","Sai","Pramila","Main mama"},
				 {"Ramesh","Muruga","Kousalya","krishha"},
				 {"sudha amma","senthi amma","rathi amma","Mads"},
				 {"Dharan", "Shrisai", "Shivan", "Aiswarya"}
	 };
		 
		 for(int i=0;i<sample.length;i++) {
			 for(int j=0;j<sample[i].length;j++) {
				 System.out.println(sample[i][j]);
			 }
		 System.out.println();
		 }
*/
		
		/********* Array List ***************/
		// Arraylist : it is resizable array. element can add and remove the after that complier phase store by reference data types
		/*
		ArrayList<String> name1 = new ArrayList<String>();
		
		name1.add("Aishu");
		name1.add("pramila");
		name1.add("sai");
		
		name1.set(0, "Aishusai");
		for(int i=0;i<name1.size();i++) {
			System.out.println(name1.get(i));
		}
		  for (int i = 0; i < name1.size(); i++) {
	            System.out.print(name1.get(i) + " "); // Print elements with a space between them
	        }
		
		System.out.println("");
		
		ArrayList<Integer> age=new ArrayList<>();
		age.add(7);
		age.add(8);
		age.add(6);
		age.add(89);
		
		age.set(2, 90);
		
		// Correcting the first loop to use size() and get() method
        for (int i1 = 0; i1 < age.size(); i1++) {
            System.out.println(age.get(i1)); // Use get() to access elements
        }
        
        // Second loop is correct, but let's add a space between the numbers for clarity
        for (int i = 0; i < age.size(); i++) {
            System.out.print(age.get(i) + " "); // Print elements with a space between them
        }
		*/
		/****** array list using user input  and for loop*********************/
		/*
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Array List details");
		
		ArrayList<Integer> age1 =new ArrayList<Integer>();
	
		  // Read the number of integers to add to the ArrayList
        System.out.println("Enter the number of ages you want to input:");
    	int age2=scanner.nextInt();
    	
		scanner.nextLine();
		
		   // Read the age values and add them to the age1 ArrayList
        System.out.println("Enter the integer types (ages):");
        for (int i = 0; i < age2; i++) {
            int age = scanner.nextInt(); // Read each age
            age1.add(age); // Add the age to the list
        }
        
		
        //Create an ArrayList to store names
        ArrayList<String> name1 = new ArrayList<String>();

        // Ask for the number of names to input
        System.out.println("Enter the number of names you want to input:");
        int nameCount = scanner.nextInt(); // Input the number of names
        
        // Clear the buffer after reading an integer
        scanner.nextLine();

        // Read the name values and add them to the name1 ArrayList
        System.out.println("Enter the names:");

        // Loop to read 'nameCount' number of names
        for (int i = 0; i < nameCount; i++) {
            String name = scanner.nextLine(); // Read each name
            name1.add(name); // Add the name to the list
        }

      
        // Close the scanner
        scanner.close();
        */
		/******** 2D array list*******************/
		/*
		Scanner scanner = new Scanner(System.in);
		
		  // Create a 2D ArrayList to store data
        ArrayList<ArrayList<String>> data = new ArrayList<ArrayList<String>>();

        // Read the number of elements for the first and second lists
        System.out.println("Enter the 2D array list details below:");

        // Input for number of elements in the first list (name1)
        System.out.print("Enter the number of elements for name1: ");
        int name1Count = scanner.nextInt();  // Read the number of elements for name1
        scanner.nextLine();  // Clear the buffer

        // Create an ArrayList for name1
        ArrayList<String> sample = new ArrayList<String>();
        System.out.println("Enter the reference types for name1:");
        for (int i = 0; i < name1Count; i++) {
            String sample3 = scanner.nextLine();  // Read each element for name1
            sample.add(sample3);  // Add it to the first list
        }

        // Input for number of elements in the second list (name2)
        System.out.print("Enter the number of elements for name2: ");
        int name2Count = scanner.nextInt();  // Read the number of elements for name2
        scanner.nextLine();  // Clear the buffer

        // Create an ArrayList for name2
        ArrayList<String> sample1 = new ArrayList<String>();
        System.out.println("Enter the reference types for name2:");
        for (int j = 0; j < name2Count; j++) {
            String sample4 = scanner.nextLine();  // Read each element for name2
            sample1.add(sample4);  // Add it to the second list
        }

        // Add both lists (sample1 and sample) to the 2D ArrayList data
        data.add(sample1);
        data.add(sample);

        // Print the 2D ArrayList data
        System.out.println("2D ArrayList data: ");
        System.out.println(data);

        // Close the scanner
        scanner.close();
        */
		
	/************* String method*****************/
		/*
		String name= "Aiswarya Pramila"             ;
		
		System.out.println("this letter character:"+name.charAt(0));
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
		//System.out.println(name.indexOf("Aishu"));
		System.out.println(name.length());
		System.out.println(name.isEmpty());
		System.out.println(name.replace("Aiswarya", "Aishu"));
		System.out.println(name.trim());
		System.out.println(name.isBlank());
		*/
		
		/********For each loop statement****************/
		
		String name = "Ishu";
		for (int i = 0; i < name.length(); i++) {
		    System.out.println(name.charAt(i));
		}
		System.out.println("");
		for (char ch : name.toCharArray()) {
		    System.out.println(ch);
		}
		
		String[] name1 = {"Aishu","Pramila"};
		for ( String i: name1) {
			System.out.println(i);
		}
		
    }
}			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			