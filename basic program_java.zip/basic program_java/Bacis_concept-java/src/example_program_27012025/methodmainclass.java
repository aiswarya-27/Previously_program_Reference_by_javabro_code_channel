package example_program_27012025;

public class methodmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age=90;
		String name="Aishu";
		add(age,name);
	
		double d=78.6;
		float f=56.34f;
		add1(d,f);
		
		
	}

 static void add(int age, String name) {
	 System.out.println("This my method function:"+" "+age+" "+name);
 }
 
 static double add1(double d,float f) {
	 System.out.println("This my Primitive data type here");
	 System.out.println("double value :"+ d);
	 System.out.println("Float value:"+ f);
	 return d + f;  // Returning some value as required by the method signature
	 
 }
}
