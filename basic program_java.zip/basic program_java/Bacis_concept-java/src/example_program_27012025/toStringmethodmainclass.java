package example_program_27012025;

public class toStringmethodmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ToStringMethod a = new ToStringMethod("Example Name");   //textually present
		
        //System.out.println(a.toString());    // explicity
		System.out.println("This my string method:"+a);  // implicity

	}

}
