package java_overview_topic;

public class SampleprogramJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	// variable 
		//how to declared variable in differences datatypes
		// datatype name: int, boolean, String, double,char
		//variable name:a,Boolean,name,Double,Char
		int a=123;
		boolean Boolean =true;
		String name ="Aishu";
		double Double =678.70;
		char Char ='#';
		
	// know we can see the how call variable 
		System.out.println(a);
		System.out.println(Boolean);
		System.out.println(name );
		System.out.println(Double);
		System.out.println( Char);
		
	}
	

}
