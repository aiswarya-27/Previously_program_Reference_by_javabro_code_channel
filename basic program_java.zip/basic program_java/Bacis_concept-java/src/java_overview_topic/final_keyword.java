package java_overview_topic;

public class final_keyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
final double AGE=90.89;
System.out.println(AGE);

System.out.println("");

final int NUMBER =809;
System.out.println(NUMBER);

System.out.println("");

final char NUMBER1 ='A';
System.out.println(NUMBER1);






	}
}
