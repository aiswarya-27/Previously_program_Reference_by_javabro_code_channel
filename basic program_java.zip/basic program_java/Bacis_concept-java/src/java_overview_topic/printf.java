package java_overview_topic;

public class printf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age =190;
		boolean Boolean =true;
		String string ="A868582";
		char Char='A';
		double Double=8709.87987;
		
		System.out.printf("Age : %d\n",age);
		System.out.printf("boolean : %b\n",Boolean) ;
		System.out.printf("String: %s\n",string) ;
		System.out.printf("char: %c\n",Char) ;
		System.out.printf("double: %f\n",Double) ;
	}

}
