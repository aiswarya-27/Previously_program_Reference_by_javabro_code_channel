package sample_question_java_bacis;

public class AbstractClass {
	// body is not necessary
	//method name Emplydeatils


void emplydetails() {
	// TODO Auto-generated method stub
	
}

}
