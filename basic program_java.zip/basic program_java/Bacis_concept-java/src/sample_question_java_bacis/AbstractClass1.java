package sample_question_java_bacis;

public class AbstractClass1 extends AbstractClass {
	@Override
	void emplydetails() {
		System.out.println("This my abstract function there i have to call");
		System.out.println("This my abstract function there i have to call1");
	}
	

}
