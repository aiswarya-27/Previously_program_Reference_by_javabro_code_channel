package sample_question_java_bacis;

public class Abstractmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 AbstractClass1 a= new  AbstractClass1();
		 AbstractClass1 b= new  AbstractClass1();
		 a.emplydetails();
		 
	}

}
