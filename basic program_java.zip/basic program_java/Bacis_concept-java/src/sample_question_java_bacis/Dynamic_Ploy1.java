package sample_question_java_bacis;

public class Dynamic_Ploy1 {

	public void xxx() {
		// TODO Auto-generated method stub
		
	}

}
