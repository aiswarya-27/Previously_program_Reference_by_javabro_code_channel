package sample_question_java_bacis;

public  class Dynamic_Ploy2 extends Dynamic_Ploy1{
	@Override
  public void xxx(){
  
  System.out.println("xxx is value");
}
}
