package sample_question_java_bacis;

import java.util.Scanner;

public class Dynamic_Ploy_mainclass {

	//private static final String Dynamic_Ploy = "A868582";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        // Read a string input (not used in this example but kept for future logic)
        System.out.println("Enter any string (optional input):");
        String dynamicInput = scanner.nextLine();

        // Prompt for choice
        System.out.println("(1 = Dynamic_Ploy2) or (2 = Dynamic_Ploy3):");
        int choice = scanner.nextInt();

        // Polymorphic behavior
        Dynamic_Ploy1 dynamic_ploy1;
        if (choice == 1) {
            dynamic_ploy1 = new Dynamic_Ploy2();
            dynamic_ploy1.xxx();
        } else if (choice == 2) {
            dynamic_ploy1 = new Dynamic_Ploy3();
            dynamic_ploy1.xxx();
        } else {
            System.out.println("Invalid choice. Please enter 1 or 2.");
        }

        scanner.close();
	}

}
