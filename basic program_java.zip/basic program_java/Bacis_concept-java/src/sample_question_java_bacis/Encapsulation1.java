package sample_question_java_bacis;

public class Encapsulation1 {
	   private String dasid;         // Private member variable for encapsulation
	    private String empdetails;    // Private member variable for encapsulation
	    private int num;              // Private member variable for encapsulation

	    // Constructor to initialize the attributes
	    public Encapsulation1(String dasid, String empdetails, int num) {
	        this.setDasId(dasid);           // Use setter to set dasid
	        this.setEmpdetails(empdetails); // Use setter to set empdetails
	        this.setNum(num);               // Use setter to set num
	    }

	    // Getter for dasid
	    public String getDasId() {
	        return dasid;
	    }

	    // Setter for dasid
	    public void setDasId(String dasid) {
	        this.dasid = dasid;
	    }

	    // Getter for empdetails
	    public String getEmpdetails() {
	        return empdetails;
	    }

	    // Setter for empdetails
	    public void setEmpdetails(String empdetails) { // Parameter name is corrected to match usage
	        this.empdetails = empdetails;
	    }

	    // Getter for num
	    public int getNum() {
	        return num;
	    }

	    // Setter for num
	    public void setNum(int num) {
	        this.num = num;  // Properly update the field
	    }
}
