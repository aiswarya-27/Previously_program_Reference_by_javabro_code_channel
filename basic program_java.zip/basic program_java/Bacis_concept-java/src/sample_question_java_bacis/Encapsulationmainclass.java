package sample_question_java_bacis;

public class Encapsulationmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation1 encap= new Encapsulation1("A868582","75059571",12345);
		 // Print the values using getters
		Encapsulation1 encap1= new Encapsulation1("A868582$","75059571A",123458);

        // Modify the value of num using setter
        encap.setNum(5678);
        //System.out.println("Updated Number: " + encap.getNum());
        System.out.println("Das ID: " + encap.getDasId());
        System.out.println("Employee Details: " + encap.getEmpdetails());
        System.out.println("Number: " + encap.getNum());
        
        
        System.out.println("Das ID: " + encap1.getDasId());
        System.out.println("Employee Details: " + encap1.getEmpdetails());
        System.out.println("Number: " + encap1.getNum());
	}

}
