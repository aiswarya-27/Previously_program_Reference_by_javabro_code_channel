package sample_question_java_bacis;

public class Ploy2 extends Poly1{
	// sub class
	// keyword : extends,  method name should same only : sample
	// body is not needed  or not required
public void sample() {
	System.out.println("the tesing sample ploy2");
}

String num="B123456";
@Override
public String sample1() {
	return num;
	
}
}
