package sample_question_java_bacis;

public class Ploy3 extends Poly1{
	// sub class
	// keyword : extends,  method name should same only : sample
		// body is not needed
	public void sample() {
		System.out.println("the tesing sample for ploy3");
	}
	
	String num="A868582";
	 @Override
	public String sample1() {
		return num;
		
	}
}
