package sample_question_java_bacis;

public class Poly1 {
	// super class

	// auto generated line 6 to 9
	public void sample() {
		// TODO Auto-generated method stub
		
	}

	public String sample1() {
		String num;
		// TODO Auto-generated method stub
		return "Default from Poly1";
	}



}
