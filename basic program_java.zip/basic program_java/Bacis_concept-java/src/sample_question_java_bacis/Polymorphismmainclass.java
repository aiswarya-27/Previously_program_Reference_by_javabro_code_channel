package sample_question_java_bacis;

public class Polymorphismmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Ploy3 ploy3 =new Ploy3();
Ploy2 ploy2 =new Ploy2();
Poly1[] polymorsphism = {ploy3,ploy2};
for(Poly1 xxx:polymorsphism ) {
	//sample  , sample 1: method name
	xxx.sample();
	xxx.sample1();
	System.out.println("Result from sample1(): " + xxx.sample1()); // Calls the overridden sample1() method
}

	}

}
