package sample_question_java_bacis;

import java.util.Scanner;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*1. Hello and Name Printer

Write a Java program to print 'Hello' on screen and your name on a separate line.
Expected Output :
Hello
Alexandra Abramov*/
		
		
		Scanner scanner =new Scanner(System.in);
		System.out.print("Hello");
		String string =scanner.nextLine();
		System.out.println("Enter your name pls: "+string);
		
		scanner.nextLine();
	}

}
