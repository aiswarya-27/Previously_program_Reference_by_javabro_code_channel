package SampleProgramPackage;

import SampleTools.Toolboxs;
// package name: SampleTool ; class name: Toolboxs
import javax.swing.*;

public class Package {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Toolboxs a= new Toolboxs();
	}

}
