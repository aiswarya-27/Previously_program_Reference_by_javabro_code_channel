package SampleTools;

public class Toolboxs {

	public Toolboxs(){
		System.out.println("Successful msg in Package ");
	}
}
