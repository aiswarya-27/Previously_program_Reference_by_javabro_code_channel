package Deserializer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.io.Serializable;
public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		/***************Deserializer************/
		/*
		 * 1.your object ( don't instantiate
		 * 2.your object class should implement Serialization Interface
		 * 2.add import java.io.Serializable;
		 * 3.FileInputStream fileIn= new FileInputStream("file path");
		 * 4.ObjectInputStream In=new ObjectInputStream(fileIn);
		 * 5.ObjectName =(Class) in.redObject();
		 * 6.in.close(); 
		 * 7.fileIn.close();
		 */
/*
1. children classes of a parent class that implements Serializable will do so as well 
2. static fields are not serialized (they belong to the class, not an individual object) 
3. the class's definition ("class file") itself is not recorded, cast it as the object type 
4. Fields declared as "transient" aren't serialized, they're ignored 
5. serialVersionUID is a unique version ID
*/
		
		/*
		 *serialVersionUID noted: serialVersionUID is a unique ID that functions like a version # 
                                 verifies that the sender and receiver of a serialized object, 
                                  have loaded classes for that object that match 
                                  Ensures object will be compatible between machines 
                                   Number must match. otherwise this will cause a InvalidClassException 
                                  A SerialVersionUID will be calculated based on class properties, members, etc. A serializable class can declare its own serialVersionUID explicitly (recommended)
		 */
		
		User user = new User();
		
		//user.no="A1234567";
		//user.das_id="Aiswaryasai";
		//user.perno=9484;
		
		//3. the class's definition ("class file") itself is not recorded, cast it as the object type 
		//FileInputStream fileIn= new FileInputStream("file path");
		FileInputStream fileIn= new FileInputStream("C://BGV_BackEnd//SampleSerialization//UserInfo.ser");
		
		//ObjectInputStream In=new ObjectInputStream(fileIn);
		ObjectInputStream in =new ObjectInputStream(fileIn);
		
		//ObjectName =(Class) in.redObject();
		try {
			user =(User) in.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		in.close();
		fileIn.close();
		
		
		
		System.out.println(user.no);
		System.out.println(user.das_id);
		System.out.println(user.perno);
		
		user.sampleserialization();
		
		/********* output: Deserializer.User: static final long serialVersionUID = -459997602440838439L;*************/
		/******* method using Serialization ***********************/
		// line 83 to 95
ObjectStreamClass serialVersionUID =ObjectStreamClass.lookup(user.getClass());
		
		getserialVersionUID();
		
		System.out.println(serialVersionUID);
		
		
	}

	private static void getserialVersionUID() {
		// TODO Auto-generated method stub
		
	}

}
