package Deserializer;

import java.io.Serializable;
/*
public class User implements Serializable{
	//1.your object class should implement Serialization Interface
	//private static final long serialVersionUID = 1; // Recommended for version control
	String no;
	//4. Fields declared as "transient" aren't serialized, they're ignored 
	// transient String das_id;
	String das_id;
	int perno;
	
	public void sampleserialization() {
		System.out.println("123!"+no);
		System.out.println("A868582"+das_id);
		System.out.println(123+perno);
	}

}
*/

/********* output: Deserializer.User: static final long serialVersionUID = -459997602440838439L;*************/
/******* method using Serialization ***********************/
public class User implements Serializable{
	//1.your object class should implement Serialization Interface
   //private static final long serialVersionUID = 1L; // Recommended for version control
	
	String no;
	//4. Fields declared as "transient" aren't serialized, they're ignored 
	transient String das_id;
	//String das_id;
	int perno;
	
	public void sampleserialization() {
		System.out.println("123!"+""+no);
		System.out.println("A868582"+""+das_id);
		System.out.println(123+""+perno);
	}

}
