package Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		/***********Serialization****************/
		/*
		 * 1.your object class should implement Serialization Interface
		 * 2.add import java.io.Serializable;
		 * 3.FileOutputStream fileOut= new FileOutputStream("file path");
		 * 4.ObjectOutputStream Out=new ObjectOutputStream(file Out);
		 * 5.Out.writeObject(objectName);
		 * 6.Out.close(); 
		 * 7.fileOut.close();
		 */
		
		User user = new User();
		user.no="A1890";
		user.das_id="A1234";
		user.perno=6789;
		
		user.sampleserialization();
		
		//3.FileOutputStream fileOut= new FileOutputStream(file path)
		FileOutputStream fileOut= new FileOutputStream("UserInfo.ser");
		
		//4.ObjectOutputStream Out=new ObjectOutputStream(file Out)
		ObjectOutputStream Out=new ObjectOutputStream(fileOut);
		
		//5.out.writeObject(objectName);
		Out.writeObject(user);
		
		//6.Out.close();
		Out.close();
		
		//7.fileOut.close();
		fileOut.close();
		
		System.out.println("successful msg in serialization");
		
		ObjectStreamClass serialVersionUID =ObjectStreamClass.lookup(user.getClass());
		
		getserialVersionUID();
		
		System.out.println(serialVersionUID);
		
		
	}

	private static void getserialVersionUID() {
		// TODO Auto-generated method stub
		
	}

}
