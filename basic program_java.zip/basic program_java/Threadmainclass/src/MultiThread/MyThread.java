package MultiThread;

public class MyThread  extends Thread{
	
	public void run() {
		
		for(int i=10;i>0;i--) {
			System.out.println("Thread #1 :"+i);
			//Thread.sleep(1000);// this is mandatory auto generated the try and catch code 
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		System.out.println("Thread # is data 1 :finsihed" );
	}

}
