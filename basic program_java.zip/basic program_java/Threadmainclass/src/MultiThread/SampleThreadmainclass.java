package MultiThread;

public class SampleThreadmainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyThread a= new MyThread();
		
		MyRunnable b= new MyRunnable();
		
		// argument name b
		// call there the argument name in line 14
		Thread a1= new Thread(b);
		
		a.start();
		//a.join(3000);
		// auto generted code
		try {
			a.join(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		a1.start();
		
		
		//a.start();
		
		//System.out.println(Thread.currentThread().getName());
		
		
	}

}
