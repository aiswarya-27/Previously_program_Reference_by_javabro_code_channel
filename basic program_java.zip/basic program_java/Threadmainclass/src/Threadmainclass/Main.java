package Threadmainclass;

public class Main {

	
	//public static void main(String[] args) throws InterruptedException {
	
		
		// TODO Auto-generated method stub

		/*********** Common keyword: Thread  ************/
		
		/** class name : threadsamplemain is not matched to it will not run the code itself.this code(Thread.activeCount())
		System.out.println(Thread.activeCount());
		// output : activeCount :1 
		
		Thread.currentThread().setName("Sample Main");
	//output : setName: Sample main ( we can change the name)
		
		System.out.println(Thread.currentThread().getName());
		// output: getName : main
		
		//Thread.currentThread().setPriority(10);
		// output: 10 we have passing the setPriority number above line same output showing in console itself
		
		Thread.currentThread().setPriority(8);
		// output: 8 we have passing the setPriority number above line same output showing in console itself
		
		System.out.println(Thread.currentThread().getPriority());
	// (example:1  to 10 number random printed in console itslef)
		//output:getPriority : 5
		
		System.out.println(Thread.currentThread().isAlive());
		// true or false condition : isAlive

		// in console itself 5 to 1 to print after that System.out.println("my  career successfully in backend developer in tcs employee in future");
		for(int i=5;i>0;i--) {
			System.out.println(i);
			Thread.sleep(1000);
			// sleep is means that min
		}
		
		System.out.println("my  career successfully in backend developer in tcs employee in future");
		
		
		for(int i=10;i>2;i--) {
			System.out.println(i);
			Thread.sleep(1000);
			// sleep is means that min
		}
		System.out.println("Definely i wil be back end devloper in tcs employee ");
		*********************/
		
	public static void main(String[] args) {
		
		MyThread a= new MyThread();
		
		// true or false condition
		System.out.println("Is main thread alive? " + Thread.currentThread().isAlive());

        // Start the thread using the start() method
        //a.start();
		a.samplerun();
        
        // Set a name for the thread
        a.setName("My 2nd Thread");
        System.out.println("Thread Name: " + a.getName());
        
        // Wait for thread completion
     
        
        System.out.println("Main thread execution completed.");
        
        
       Thread.currentThread().setPriority(10);
        //output: 10 we have passing the setPriority number above line same output showing in console itself
        
        System.out.println(a.getPriority());
        // random number print in console 1 to 5
        
        System.out.println(Thread.activeCount());
		// output : activeCount :1 
        
        // true or false condition
        a.setDaemon(true);
        System.out.println(a.isDaemon());
        
       
        
    }
}






