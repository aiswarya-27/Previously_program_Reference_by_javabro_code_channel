package Threadmainclass;

public class MyThread extends Thread{
	public void samplerun() {
		
		
		if(this.isDaemon()) {
			System.out.println("Sample Thread is running 1...");
		}
		else {
			System.out.println("Sample Thread is running 2...");
		}
		System.out.println("Sample Thread is running...");
		
	}





}
